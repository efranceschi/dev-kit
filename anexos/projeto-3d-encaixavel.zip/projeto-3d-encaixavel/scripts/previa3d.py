"""Gera o visualizador HTML com as malhas embutidas.

Consome as peças no referencial de montagem e uma lista de instâncias com
matriz de transformação e vetor de explosão. Ver references/visualizador.md.

    from previa3d import gerar
    gerar('previa.html',
          malhas={'BX': malha_bx, 'LF': malha_lf},
          instancias=[dict(m='BX', M=matriz4x4, g='base', e=[0,-80,0]), ...],
          centro=[x, y, z],
          familias=[('base','Bases','6'), ('coluna','Montantes','4')])
"""

import json
import numpy as np

CORES = {0: 0x4f9d86, 1: 0x3d8f78, 2: 0x2a6d5b, 3: 0x5fb09a}


def _malha(m):
    return dict(pos=np.round(m.vertices, 2).astype(np.float32).ravel().tolist(),
                idx=m.faces.astype(np.int32).ravel().tolist(),
                ext=[round(x, 1) for x in m.extents],
                vol=round(m.volume / 1000, 2))


def gerar(saida, malhas, instancias, centro, familias, titulo='Prévia 3D',
          deitadas=None, info=None):
    """deitadas: malhas na orientação de impressão (opcional, para a aba Peça).
    info: {codigo: (nome, quantidade, observacao)}"""
    dados = dict(
        mont={k: _malha(v) for k, v in malhas.items()},
        deit={k: _malha(v) for k, v in (deitadas or malhas).items()},
        inst=[dict(m=i['m'], M=[round(x, 4) for x in np.asarray(i['M']).ravel().tolist()],
                   g=i['g'], e=i['e']) for i in instancias],
        centro=[round(c, 1) for c in centro],
        familias=[list(f) for f in familias],
        cores={f[0]: CORES[n % 4] for n, f in enumerate(familias)},
        info=info or {},
        titulo=titulo,
    )
    html = _TEMPLATE.replace('__DADOS__', json.dumps(dados, separators=(',', ':')))
    open(saida, 'w', encoding='utf-8').write(html)
    _conferir(saida)
    return saida


def _conferir(caminho):
    """Tela preta silenciosa é o pior modo de falha — confira o fechamento."""
    import re, subprocess, tempfile
    s = open(caminho, encoding='utf-8').read()
    assert s.rstrip().endswith('</html>'), 'HTML sem fechamento'
    js = re.findall(r'<script(?![^>]*src)[^>]*>(.*?)</script>', s, re.S)
    assert js, 'bloco <script> não fechado'
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False) as f:
        f.write(js[0]); tmp = f.name
    try:
        subprocess.run(['node', '--check', tmp], check=True, capture_output=True)
    except FileNotFoundError:
        pass


_TEMPLATE = r'''<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--ink:#1b1f1e;--ink2:#5b6360;--paper:#f2f1ec;--rule:#d6d5cd;--acc:#1f7a63;--soft:#dcebe5;--void:#191d1f}
*{box-sizing:border-box}html,body{height:100%;height:100dvh;margin:0;overscroll-behavior:none}
body{font-family:'IBM Plex Sans',system-ui,sans-serif;background:var(--void);color:var(--ink);overflow:hidden}
#stage{position:fixed;inset:0}canvas{display:block;touch-action:none}
#erro{position:fixed;left:320px;top:16px;right:16px;background:#3a1a10;color:#f0c4a8;
 font-size:13px;padding:12px;border-left:3px solid #a8481f;display:none;white-space:pre-wrap}
#panel{position:fixed;top:0;left:0;bottom:0;width:290px;background:var(--paper);
 border-right:1px solid var(--rule);overflow-y:auto;padding:20px 18px 26px}
h1{font-size:17px;font-weight:600;margin:0 0 14px}
fieldset{border:0;border-top:1px solid var(--rule);margin:0 0 14px;padding:12px 0 0}
legend{font-size:12px;font-weight:600;color:var(--ink2)}
.ch{display:flex;justify-content:space-between;margin-bottom:5px;font-size:13px}
.ch output{font-weight:600;color:var(--acc)}
input[type=range]{width:100%;height:24px;-webkit-appearance:none;background:transparent}
input[type=range]::-webkit-slider-runnable-track{height:2px;background:var(--rule)}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;
 border-radius:50%;background:var(--acc);margin-top:-7px}
.lista{display:flex;flex-direction:column;gap:5px}
.lista button{font:inherit;font-size:12.5px;text-align:left;padding:9px 10px;border:1px solid var(--rule);
 background:transparent;color:var(--ink);border-radius:2px;cursor:pointer;display:flex;
 justify-content:space-between;gap:8px;min-height:40px;align-items:center}
.lista button[aria-pressed=true]{background:var(--soft);border-color:var(--acc);color:var(--acc);font-weight:600}
.lista span{color:var(--ink2);font-weight:400}
#alca{display:none}
@media (max-width:760px){
 #panel{top:auto;left:0;right:0;width:auto;max-height:80dvh;border-right:0;
  border-top:1px solid var(--rule);border-radius:15px 15px 0 0;padding:0 16px 20px;
  transition:transform .22s ease;box-shadow:0 -8px 28px rgba(0,0,0,.35)}
 #panel.recolhido{transform:translateY(calc(100% - 150px))}
 #alca{display:block;position:sticky;top:0;width:100%;background:var(--paper);border:0;padding:11px 0 9px;cursor:pointer}
 #alca::before{content:'';display:block;width:42px;height:4px;border-radius:2px;background:var(--rule);margin:0 auto}
 h1{display:none}#erro{left:16px}}
</style></head><body>
<div id="stage"></div><div id="erro"></div>
<div id="panel" class="recolhido"><button id="alca"></button><h1 id="tit"></h1>
<fieldset><legend>Separar</legend>
<div class="ch"><label for="exp">Explosão</label><output id="expo">0%</output></div>
<input type="range" id="exp" min="0" max="100" value="0"></fieldset>
<fieldset><legend>Destacar família</legend><div class="lista" id="fam"></div></fieldset>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
const D=__DADOS__;
function falhar(m){const e=document.getElementById('erro');e.textContent=m;e.style.display='block';}
window.addEventListener('error',ev=>falhar(ev.message));
if(typeof THREE==='undefined'){falhar('three.js não carregou.');}
let scene,camera,renderer,grupo,pivo,geos={},girando=true,exp=0,destaque=null;
const orb={theta:-.85,phi:1.0,raio:900},FOV=38*Math.PI/180;
function geo(n){if(geos[n])return geos[n];const d=D.mont[n],g=new THREE.BufferGeometry();
 g.setAttribute('position',new THREE.Float32BufferAttribute(d.pos,3));g.setIndex(d.idx);
 g.computeVertexNormals();return geos[n]=g;}
function montar(){grupo=new THREE.Group();
 D.inst.forEach(it=>{const m=new THREE.Mesh(geo(it.m),new THREE.MeshStandardMaterial(
  {color:D.cores[it.g],roughness:.55,transparent:true,opacity:1}));
  const M=new THREE.Matrix4();M.set(...it.M);m.userData={base:M,e:it.e,g:it.g};
  m.matrixAutoUpdate=false;grupo.add(m);});
 grupo.position.set(-D.centro[0],-D.centro[1],-D.centro[2]);
 pivo=new THREE.Group();pivo.add(grupo);scene.add(pivo);}
function aplicar(){grupo.children.forEach(m=>{const M=m.userData.base.clone(),e=m.userData.e,f=exp/100;
 M.premultiply(new THREE.Matrix4().makeTranslation(e[0]*f,e[1]*f,e[2]*f));
 m.matrix.copy(M);m.updateMatrixWorld(true);
 const on=!destaque||m.userData.g===destaque;m.material.opacity=on?1:.1;m.material.depthWrite=on;});}
function livre(){const p=document.getElementById('panel').getBoundingClientRect(),mv=innerWidth<=760;
 return [(mv?innerWidth/2:(p.right+innerWidth)/2)-innerWidth/2,
         (mv?Math.max(p.top,120)/2:innerHeight/2)-innerHeight/2];}
function anima(){requestAnimationFrame(anima);if(girando&&pivo)pivo.rotation.y+=.004;
 const pos=new THREE.Vector3(orb.raio*Math.sin(orb.phi)*Math.sin(orb.theta),
  orb.raio*Math.cos(orb.phi),orb.raio*Math.sin(orb.phi)*Math.cos(orb.theta));
 const dir=pos.clone().negate().normalize();
 const ex=new THREE.Vector3().crossVectors(dir,new THREE.Vector3(0,1,0)).normalize();
 const ey=new THREE.Vector3().crossVectors(ex,dir).normalize();
 const wpp=(2*orb.raio*Math.tan(FOV/2))/innerHeight,[sx,sy]=livre();
 const foco=ex.multiplyScalar(-sx*wpp).add(ey.multiplyScalar(sy*wpp));
 camera.position.copy(pos).add(foco);camera.lookAt(foco);renderer.render(scene,camera);}
function iniciar(){document.getElementById('tit').textContent=D.titulo;
 scene=new THREE.Scene();scene.background=new THREE.Color(0x191d1f);
 camera=new THREE.PerspectiveCamera(38,innerWidth/innerHeight,1,6000);
 renderer=new THREE.WebGLRenderer({antialias:true});
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);
 document.getElementById('stage').appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xdfe9e6,0x20282a,.9));
 const l=new THREE.DirectionalLight(0xffffff,.8);l.position.set(300,500,400);scene.add(l);
 const l2=new THREE.DirectionalLight(0xffffff,.3);l2.position.set(-350,150,-250);scene.add(l2);
 montar();aplicar();
 const fam=document.getElementById('fam');
 D.familias.forEach(([k,t,q])=>{const b=document.createElement('button');
  b.innerHTML='<b>'+t+'</b><span>'+q+'</span>';b.setAttribute('aria-pressed','false');
  b.onclick=()=>{destaque=destaque===k?null:k;[...fam.children].forEach(x=>x.setAttribute('aria-pressed','false'));
   if(destaque)b.setAttribute('aria-pressed','true');aplicar();};fam.appendChild(b);});
 document.getElementById('exp').addEventListener('input',e=>{exp=+e.target.value;
  document.getElementById('expo').textContent=exp+'%';aplicar();});
 const painel=document.getElementById('panel');
 document.getElementById('alca').onclick=()=>painel.classList.toggle('recolhido');
 if(innerWidth<=760)orb.raio=1150;
 const el=renderer.domElement;let drag=false,lx=0,ly=0,pin=0;
 el.addEventListener('pointerdown',e=>{if(e.isPrimary===false)return;drag=true;lx=e.clientX;ly=e.clientY;girando=false;});
 addEventListener('pointerup',()=>drag=false);
 el.addEventListener('pointermove',e=>{if(!drag)return;orb.theta-=(e.clientX-lx)*.006;
  orb.phi=Math.max(.12,Math.min(Math.PI-.12,orb.phi-(e.clientY-ly)*.006));lx=e.clientX;ly=e.clientY;});
 el.addEventListener('wheel',e=>{e.preventDefault();
  orb.raio=Math.max(30,Math.min(3000,orb.raio*(1+Math.sign(e.deltaY)*.11)));},{passive:false});
 el.addEventListener('touchstart',e=>{if(e.touches.length===2){drag=false;
  pin=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);}},{passive:true});
 el.addEventListener('touchend',()=>{pin=0;},{passive:true});
 el.addEventListener('touchmove',e=>{if(e.touches.length===2&&pin){
  const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
  orb.raio=Math.max(30,Math.min(3000,orb.raio*pin/d));pin=d;e.preventDefault();}},{passive:false});
 anima();}
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;
 camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
iniciar();
</script></body></html>'''

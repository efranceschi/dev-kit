"""Esqueleto de gerador paramétrico. Copie e adapte.

Estrutura que evita retrabalho:
  1. cotas no topo, uma constante por conceito, nenhum número repetido
  2. uma função por família de peça, devolvendo a malha no referencial de MONTAGEM
  3. orientação de impressão escolhida por intenção, aplicada só na exportação
  4. validação antes de exportar
"""

import math, os
import numpy as np
from lib3d import Bx, uniao, corta, gravar, para_impressao, rot
from encaixes import pino_sextavado, furo_sextavado, junta_auto, forquilha

# ----------------------------------------------------------------- cotas
OBJ_D, OBJ_L = 50.0, 160.0        # envelope do objeto guardado
VAO, PROF, LARG = 150.0, 410.0, 430.0   # espaço disponível
ANG = 2.0                          # inclinação, calculada — não chutada
DESN = PROF * math.tan(math.radians(ANG))

ESP_MONT = 9.0                     # espessura do montante
PASSO_MOD = OBJ_L + 10             # largura de um módulo
ESTACOES = [26.0, PROF / 2, PROF - 26.0]

PIN_R, PIN_H, FURO_R = 3.425, 8.0, 3.425   # calibrar com CM1/CF1
FOLGA_RABO, FOLGA_BAIONETA = 0.20, 0.80

MESA = (250, 250, 255)
SAIDA = 'stl'

# ------------------------------------------------------------- famílias
def montante(seg):
    """Nó vertical. `seg` 'F' ou 'T' — segmentos NÃO são intercambiáveis
    quando a inclinação está codificada na altura dos encaixes."""
    ...

def ligacao(seg):
    """Vão entre dois nós. Modele PLANO; a inclinação vem das cotas do nó."""
    ...

def base(tipo):
    """tipo 'X' extremidade, 'C' central. Junta auto-acoplável nas pontas."""
    partes, cortes = [], []
    macho, soquete = junta_auto(PASSO_MOD / 2, 0, 8, +1, folga=FOLGA_RABO)
    partes.append(macho); cortes.append(soquete)
    if tipo == 'C':
        m2, s2 = junta_auto(-PASSO_MOD / 2, 0, 8, -1, folga=FOLGA_RABO)
        partes.append(m2); cortes.append(s2)
    ...

# --------------------------------------------- orientação de impressão
X, Y = [1, 0, 0], [0, 1, 0]
TAREFAS = [
    # ('LF', lambda: montante('F'), (Y, -np.pi / 2)),   # deitado na face fina
    # ('PF', lambda: ligacao('F'),  (X,  np.pi / 2)),   # saliências para cima
]

if __name__ == '__main__':
    os.makedirs(SAIDA, exist_ok=True)
    print(f'{"peça":6} {"X":>7} {"Y":>7} {"Z":>7} {"cm3":>7}  estanque  cabe')
    for nome, fn, (eixo, ang) in TAREFAS:
        m = para_impressao(fn(), eixo, ang)
        ex = m.extents
        cabe = all(e < lim for e, lim in zip(ex, MESA))
        m.export(os.path.join(SAIDA, f'{nome}.stl'))
        print(f'{nome:6} {ex[0]:7.1f} {ex[1]:7.1f} {ex[2]:7.1f} {m.volume/1000:7.1f}  '
              f'{str(m.is_watertight):8}  {"sim" if cabe else "NAO"}')

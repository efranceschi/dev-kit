import numpy as np
import trimesh
from trimesh.creation import box as _box, cylinder as _cyl, revolve

def rot(angle, axis):
    return trimesh.transformations.rotation_matrix(angle, axis)

def B(sx, sy, sz, cx=0.0, cy=0.0, cz=0.0):
    """Caixa pelos tamanhos e centro."""
    m = _box(extents=(sx, sy, sz))
    m.apply_translation((cx, cy, cz))
    return m

def Bx(x0, x1, y0, y1, z0, z1):
    """Caixa pelos limites, em qualquer ordem."""
    x0, x1 = min(x0, x1), max(x0, x1)
    y0, y1 = min(y0, y1), max(y0, y1)
    z0, z1 = min(z0, z1), max(z0, z1)
    if (x1 - x0) <= 0 or (y1 - y0) <= 0 or (z1 - z0) <= 0:
        raise ValueError(f'caixa degenerada {x0,x1,y0,y1,z0,z1}')
    return B(x1 - x0, y1 - y0, z1 - z0, (x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)

def CYL(r, h, cx, cy, cz, axis='y', sections=40):
    m = _cyl(radius=r, height=h, sections=sections)
    if axis == 'y':
        m.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    elif axis == 'x':
        m.apply_transform(rot(np.pi / 2, [0, 1, 0]))
    m.apply_translation((cx, cy, cz))
    return m

def HEX(R, h, cx, cy, cz):
    """Prisma hexagonal, eixo em Y, vértices alinhados ao eixo X.
    Impresso deitado, a metade de baixo fica a 60° — dispensa suporte."""
    m = _cyl(radius=R, height=h, sections=6)
    m.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    m.apply_translation((cx, cy + h / 2, cz))
    return m

def HEXCONE(R1, R2, h, cx, cy, cz):
    """Tronco hexagonal para a ponta de entrada."""
    perfil = np.array([[0.0, 0.0], [R1, 0.0], [R2, h], [0.0, h]])
    m = revolve(perfil, sections=6)
    m.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    m.apply_translation((cx, cy, cz))
    return m

def CONE(r_base, r_topo, h, cx, cy, cz, sections=40):
    """Tronco de cone com eixo em Y, base em cy."""
    perfil = np.array([[0.0, 0.0], [r_base, 0.0], [r_topo, h], [0.0, h]])
    m = revolve(perfil, sections=sections)
    m.apply_transform(rot(np.pi / 2, [1, 0, 0]))
    m.apply_translation((cx, cy, cz))
    return m

def RESSALTO(x0, x1, y0, altura, z_pico, z_base, eixo='z'):
    """Ressalto em rampa: sobe de z_base até z_pico e cai a pique em z_pico.
    Entra empurrando, resiste a voltar — é o que trava um encaixe deslizante
    sem parafuso e sem depender de atrito.

    Com eixo='x' o avanço é em x e a largura em z: é o mesmo ressalto visto de
    outro lado, e existe para o corpo de prova não recriar a rampa por conta
    própria. Duas cópias da mesma geometria acabam divergindo."""
    from shapely.geometry import Polygon
    from trimesh.creation import extrude_polygon
    pol = Polygon([(z_base, y0), (z_pico, y0), (z_pico, y0 + altura)])
    m = extrude_polygon(pol, abs(x1 - x0))
    m.apply_transform(rot(-np.pi / 2, [0, 1, 0]))
    m.apply_translation((max(x0, x1), 0, 0))
    if eixo == 'x':
        T = np.eye(4); T[0, 0] = T[2, 2] = 0.0; T[0, 2] = T[2, 0] = 1.0
        m.apply_transform(T)     # trimesh já corrige o sentido das faces aqui
    return m

def uniao(pecas):
    pecas = [p for p in pecas if p is not None]
    return trimesh.boolean.union(pecas)

def corta(base, ferramentas):
    ferramentas = [f for f in ferramentas if f is not None]
    if not ferramentas:
        return base
    return trimesh.boolean.difference([base] + ferramentas)


# ---------- fonte vetorial de traços retos ----------
# cada glifo: lista de (x0, y0, x1, y1) numa caixa 4.0 x 8.0
E = 1.2  # espessura do traço

GLIFOS = {
    'B': [(0, 0, E, 8), (0, 8 - E, 3.6, 8), (0, 4 - E / 2, 3.4, 4 + E / 2),
          (0, 0, 3.6, E), (3.6 - E, 4 + E / 2, 3.6, 8 - E), (3.6 - E, E, 3.6, 4 - E / 2)],
    'C': [(0, 0, E, 8), (0, 8 - E, 3.6, 8), (0, 0, 3.6, E)],
    'D': [(0, 0, E, 8), (0, 8 - E, 3.2, 8), (0, 0, 3.2, E), (3.6 - E, E, 3.6, 8 - E)],
    'F': [(0, 0, E, 8), (0, 8 - E, 3.6, 8), (0, 4 - E / 2, 3.0, 4 + E / 2)],
    'L': [(0, 0, E, 8), (0, 0, 3.6, E)],
    'P': [(0, 0, E, 8), (0, 8 - E, 3.6, 8), (0, 4 - E / 2, 3.6, 4 + E / 2),
          (3.6 - E, 4 + E / 2, 3.6, 8 - E)],
    'T': [(0, 8 - E, 3.6, 8), (1.8 - E / 2, 0, 1.8 + E / 2, 8 - E)],
    'X': [],  # diagonais tratadas à parte
    'K': [(0, 0, E, 8)],
    '1': [(1.8 - E / 2, 0, 1.8 + E / 2, 8), (0.6, 6.6, 1.8, 8)],
    '2': [(0, 8 - E, 3.6, 8), (3.6 - E, 4, 3.6, 8), (0, 4 - E, 3.6, 4), (0, 0, E, 4), (0, 0, 3.6, E)],
    '3': [(0, 8 - E, 3.6, 8), (3.6 - E, 0, 3.6, 8), (0.8, 4 - E / 2, 3.6, 4 + E / 2), (0, 0, 3.6, E)],
}

DIAGONAIS = {
    'X': [((0, 0), (3.6, 8)), ((3.6, 0), (0, 8))],
    'K': [((E, 4), (3.6, 8)), ((E, 4), (3.6, 0))],
}

def _traco_diag(p0, p1, prof, esp=E):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    comp = float(np.hypot(dx, dy))
    ang = float(np.arctan2(dy, dx))
    m = _box(extents=(comp, esp, prof))
    m.apply_transform(rot(ang, [0, 0, 1]))
    m.apply_translation(((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2, 0))
    return m

def texto_plano(txt, altura=8.0, prof=0.7, espaco=1.6):
    """Sólido do texto no plano XY, extrudado em +Z, origem no canto inferior esquerdo."""
    k = altura / 8.0
    partes, cursor = [], 0.0
    for ch in txt:
        largura = 3.6
        for (x0, y0, x1, y1) in GLIFOS.get(ch, []):
            partes.append(Bx(x0 + cursor, x1 + cursor, y0, y1, -prof / 2, prof / 2))
        for (p0, p1) in DIAGONAIS.get(ch, []):
            t = _traco_diag(p0, p1, prof)
            t.apply_translation((cursor, 0, 0))
            partes.append(t)
        cursor += largura + espaco
    if not partes:
        return None
    m = uniao(partes)
    m.apply_scale(k)
    return m

# Orientação de leitura por face. Para cada face: como o eixo de avanço do
# texto (x local) e o eixo vertical da letra (y local) se mapeiam no espaço
# da peça, de modo que o texto leia certo para quem olha aquela face.
#   olhando a face +x (de +x para -x, com +y para cima) → direita = +z
#   olhando a face -x                                   → direita = -z
#   olhando a face +y de cima, com a frente em -z        → direita = +x, topo = +z
#   olhando a face +z                                    → direita = +x
#   olhando a face -z                                    → direita = -x
# Direção de leitura de cada face, declarada em vez de deduzida por ângulo.
# `avanco` = para onde cresce o texto; `topo` = para onde aponta o alto da letra.
# Regra: para quem olha a face, a direita é (direção do olhar) x (para cima).
# Olhando a face +x (olhar em -x, cima em +y), a direita é -z — foi aqui que
# uma dedução errada espelhou o texto das faces laterais.
_FACES = {
    'YZ+x': ('x', +1, (0, 0, -1), (0, 1, 0)),
    'YZ-x': ('x', -1, (0, 0, +1), (0, 1, 0)),
    'XZ+y': ('y', +1, (-1, 0, 0), (0, 0, 1)),
    'XY+z': ('z', +1, (+1, 0, 0), (0, 1, 0)),
    'XY-z': ('z', -1, (-1, 0, 0), (0, 1, 0)),
}

def gravar(peca, txt, plano, pos, altura=8.0, prof=0.7, espelhar=None):
    """Grava texto em baixo relevo numa face, com a leitura correta para quem
    olha aquela face. A orientação vem da tabela _FACES — não há parâmetro de
    espelho para errar."""
    if plano not in _FACES:
        raise ValueError(f'face desconhecida: {plano}')
    eixo, sentido, avanco, topo = _FACES[plano]
    t = texto_plano(txt, altura=altura, prof=prof * 2.0)
    if t is None:
        return peca
    t.apply_translation(-(t.bounds[0] + t.bounds[1]) / 2)   # centrado na origem
    a = np.array(avanco, dtype=float)
    b = np.array(topo, dtype=float)
    R = np.eye(4)
    R[:3, 0], R[:3, 1], R[:3, 2] = a, b, np.cross(a, b)
    t.apply_transform(R)
    c = np.array(pos, dtype=float)      # centrado no plano: corta `prof` para dentro
    t.apply_translation(c)
    return corta(peca, [t])

def para_impressao(peca, rot_eixo=None, ang=0.0):
    """Rotaciona e apoia a peça em Z=0 para fatiar."""
    m = peca.copy()
    if rot_eixo is not None:
        m.apply_transform(rot(ang, rot_eixo))
    m.apply_translation(-m.bounds[0])
    return m

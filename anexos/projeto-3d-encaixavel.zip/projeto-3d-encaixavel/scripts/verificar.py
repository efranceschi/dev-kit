"""Bateria de verificação para conjuntos encaixáveis.

Importe e chame as funções passando as peças já posicionadas no referencial de
montagem. As seis famílias correspondem a references/validacao.md.

    from verificar import *
    rel = Relatorio()
    rel.interferencia('coluna + base', base, coluna)
    rel.encosto('coluna assenta na base', base, coluna, 'y-')
    rel.caminho('coluna descendo', base, coluna, (0, 45, 0))
    rel.espelhamento('base + base', bx_e, bx_d_girada, bx_d_espelhada, 'x+')
    rel.imprimibilidade('LF', peca_na_orientacao_de_impressao)
    rel.mostrar()
"""

import math
import numpy as np
import trimesh


def T(m, dx=0.0, dy=0.0, dz=0.0):
    m = m.copy(); m.apply_translation((dx, dy, dz)); return m


def gira180Y(m):
    from lib3d import rot
    m = m.copy(); m.apply_transform(rot(np.pi, [0, 1, 0])); return m


def espelhaX(m):
    """Espelho em x. `invert()` é essencial: sem ele as normais ficam para dentro."""
    m = m.copy(); m.apply_transform(np.diag([-1.0, 1.0, 1.0, 1.0])); m.invert(); return m


def vol(a, b):
    try:
        c = trimesh.boolean.intersection([a, b])
        return abs(c.volume) if c is not None and len(c.faces) else 0.0
    except Exception:
        return 0.0


def _passo(eixo, d):
    v = [0.0, 0.0, 0.0]
    v['xyz'.index(eixo[0])] = d * (1 if eixo[1] == '+' else -1)
    return v


class Relatorio:
    def __init__(self):
        self.linhas = []

    def _add(self, nome, valor, ok, unidade='mm3'):
        self.linhas.append((nome, valor, ok, unidade))

    # A ------------------------------------------------------------------
    def interferencia(self, nome, a, b, tol=1.0):
        v = vol(a, b)
        self._add(f'interferência · {nome}', v, v <= tol)
        return v

    def onde(self, a, b):
        """Caixa envolvente da interseção — use para julgar se um resíduo importa."""
        c = trimesh.boolean.intersection([a, b])
        return np.round(c.bounds, 2).tolist() if c is not None and len(c.faces) else None

    # B ------------------------------------------------------------------
    def encosto(self, nome, a, b, eixo, d=1.5, minimo=1.0):
        """Aproxima b de a; se estavam em contato, aparece interferência."""
        v = vol(a, T(b, *_passo(eixo, d)))
        self._add(f'encosto · {nome}', v, v >= minimo)
        return v

    def separacao(self, nome, a, b, eixo, d=1.5, minimo=5.0):
        """Afasta na direção em que a junta deve travar. Rabo engatado interfere."""
        v = vol(a, T(b, *_passo(eixo, d)))
        self._add(f'resiste a separar · {nome}', v, v >= minimo)
        return v

    # C ------------------------------------------------------------------
    def caminho(self, nome, fixa, movel, vetor, n=22, tol=0.5):
        """Varre a aproximação. Caber na posição final não prova que há trajeto."""
        ruins = [round(k / n, 2) for k in range(n, 0, -1)
                 if vol(fixa, T(movel, *[c * k / n for c in vetor])) > tol]
        self._add(f'caminho livre · {nome}', len(ruins), not ruins, 'colisões')
        return ruins

    # D ------------------------------------------------------------------
    def espelhamento(self, nome, a, b_girada, b_espelhada, eixo, d=1.5):
        """A versão correta resiste a separar; a espelhada não engata."""
        certo = vol(a, T(b_girada, *_passo(eixo, d)))
        errado = vol(a, T(b_espelhada, *_passo(eixo, d)))
        self._add(f'girada engata · {nome}', certo, certo >= 5.0)
        self._add(f'espelhada NÃO engata · {nome}', errado, errado < 1.0)
        return certo, errado

    # E ------------------------------------------------------------------
    def gravacao(self, nome, malha, face_x, janela, z_nominal, passo=0.25):
        """Ponto gravado = fora do material junto à face, dentro mais fundo.

        Compare área e centro, nunca igualdade de bitmap: a grade cai diferente
        depois do espelhamento e o XOR acusa 50% numa gravação perfeita.
        """
        def marcas(fx):
            sg = np.sign(fx)
            y0, y1, z0, z1 = janela
            ys = np.arange(y0, y1, passo); zs = np.arange(z0, z1, passo)
            Y, Z = np.meshgrid(ys, zs, indexing='ij')
            raso = np.stack([np.full(Y.size, fx - sg * 0.25), Y.ravel(), Z.ravel()], 1)
            fundo = np.stack([np.full(Y.size, fx - sg * 2.0), Y.ravel(), Z.ravel()], 1)
            M = ((~malha.contains(raso)) & malha.contains(fundo)).reshape(Y.shape)
            if not M.any():
                return 0.0, None
            iy, iz = np.where(M)
            return M.sum() * passo ** 2, (ys[iy].mean(), zs[iz].mean())
        aA, cA = marcas(+face_x); aB, cB = marcas(-face_x)
        if cA is None or cB is None:
            self._add(f'gravação nas duas faces · {nome}', 0, False, 'mm2'); return
        dArea = abs(aA - aB) / max(aA, aB)
        dPos = math.hypot(cA[0] - cB[0], (cA[1] + cB[1]) / 2 - z_nominal)
        self._add(f'gravação simétrica · {nome}', round(dArea * 100, 1),
                  dArea < 0.12 and dPos < 1.0, '% dif')

    # F ------------------------------------------------------------------
    def imprimibilidade(self, nome, peca, mesa=(250, 250, 255), min_contato=250):
        ex = peca.extents
        self._add(f'cabe na mesa · {nome}', round(max(ex), 1),
                  all(e < m for e, m in zip(ex, mesa)), 'mm')
        n, a = peca.face_normals, peca.area_faces
        ang = np.degrees(np.arcsin(np.clip(-n[:, 2], -1, 1)))
        z0 = peca.bounds[0][2]; c = peca.triangles_center[:, 2]
        suspensa = a[(ang >= 89) & (c > z0 + 0.4)].sum()
        self._add(f'face plana suspensa · {nome}', round(suspensa), True, 'mm2')
        sec = peca.section(plane_origin=[0, 0, z0 + 0.25], plane_normal=[0, 0, 1])
        area = sec.to_2D()[0].area if sec is not None else 0.0
        self._add(f'contato com a mesa · {nome}', round(area),
                  area >= min_contato, 'mm2')

    # --------------------------------------------------------------------
    def mostrar(self):
        larg = max(len(l[0]) for l in self.linhas) + 2
        falhas = 0
        for nome, valor, ok, un in self.linhas:
            falhas += 0 if ok else 1
            v = f'{valor:.2f}' if isinstance(valor, float) else str(valor)
            print(f'{nome:<{larg}} {v:>10} {un:<8} {"ok" if ok else "FALHA"}')
        print('-' * (larg + 28))
        print(f'{len(self.linhas)} verificações, {falhas} falha(s)')
        return falhas == 0

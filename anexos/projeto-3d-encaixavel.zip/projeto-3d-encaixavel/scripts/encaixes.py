"""Geradores de encaixe reutilizáveis.

Todos devolvem sólidos no referencial local da peça; posicione com
apply_translation. As folgas são parâmetros — calibre com os corpos de prova
antes de gerar as peças definitivas.
"""

import numpy as np
from lib3d import Bx, HEX, HEXCONE, uniao, rot

# ---------------------------------------------------------------- pino
def pino_sextavado(R, altura, cx, cy, cz, chanfro=2.0, reducao=0.6):
    """Pino hexagonal com ponta chanfrada, eixo em Y, base em cy.

    Hexágono em vez de cilindro porque em peça impressa deitada o eixo fica
    paralelo à mesa: as faces inferiores ficam a 60° e dispensam suporte.
    Haste reta (não cone) para que o engate seja longo e a escada de folgas
    tenha sentido.
    """
    h = altura - chanfro
    return uniao([HEX(R, h, cx, cy, cz),
                  HEXCONE(R, R - reducao, chanfro, cx, cy + h, cz)])

def furo_sextavado(R, prof, cx, cy, cz):
    """Ferramenta de corte para o furo correspondente, aberto para baixo."""
    return HEX(R, prof * 2, cx, cy - prof, cz)

# ---------------------------------------------- rabo-de-andorinha auto-acoplável
def _trapezio(larg_raiz, larg_ponta, prof, y0, y1, folga=0.0):
    from shapely.geometry import Polygon
    from trimesh.creation import extrude_polygon
    s = folga
    pol = Polygon([(-s, -larg_raiz / 2 - s), (-s, larg_raiz / 2 + s),
                   (prof + s, larg_ponta / 2 + s), (prof + s, -larg_ponta / 2 - s)])
    m = extrude_polygon(pol, y1 - y0)
    m.apply_transform(rot(-np.pi / 2, [1, 0, 0]))
    m.apply_translation((0, y0, 0))
    return m

def rabo(xr, zc, y0, y1, sentido=+1, folga=0.0,
         larg_raiz=6.0, larg_ponta=11.0, prof=8.0):
    """Um rabo-de-andorinha projetando-se em ±x a partir de xr.

    larg_ponta bem maior que larg_raiz reduz a folga axial antes de travar:
    ela vale folga_total / tan(flanco).
    """
    m = _trapezio(larg_raiz, larg_ponta, prof, y0, y1, folga)
    if sentido < 0:
        m.apply_transform(np.diag([-1.0, 1.0, 1.0, 1.0]))
        m.invert()
    m.apply_translation((xr, 0, zc))
    return m

def junta_auto(xr, y0, y1, ponta, prof_estacao=28.0, folga=0.2):
    """Extremidade auto-acoplável: meio macho e meio soquete.

    ponta +1 para a extremidade em +x, -1 para a em -x. Devolve
    (macho, soquete): some o macho à peça e corte o soquete dela.

    O módulo vizinho é ESTA MESMA PEÇA girada 180° em torno de Y — nunca
    espelhada. Espelhar não colide, apenas deixa de engatar.
    """
    q = prof_estacao / 4
    zc_macho = q if ponta > 0 else 3 * q
    zc_soq = 3 * q if ponta > 0 else q
    macho = rabo(xr, zc_macho, y0, y1, ponta)
    soquete = rabo(xr, zc_soq, y0, y1, -ponta, folga=folga)
    return macho, soquete

# ------------------------------------------------------------- baioneta em L
def baioneta_aba(xf, y_base, z_nominal, esp=2.0, alt=4.5, comp=5.0, sentido=+1):
    """A aba macho, projetando-se em ±x da borda da peça móvel."""
    return Bx(xf, xf + sentido * esp, y_base, y_base + alt,
              z_nominal - comp / 2, z_nominal + comp / 2)

def baioneta_rasgo(x_face, y_piso, z_nominal, avanco=6.0, prof=2.6,
                   alt_canal=5.6, esp=2.0, alt=4.5, comp=5.0,
                   folga=0.8, sentido=+1, topo=1e3):
    """Ferramentas de corte do rasgo em L: (descida, canal de trava).

    A posição NOMINAL é a travada; a descida fica deslocada de `avanco`.
    O contrário deixa a peça montada fora do lugar por todo o curso.
    Escolha o sentido do avanço a favor da carga de trabalho.
    """
    zd = z_nominal + avanco * (1 if sentido > 0 else -1)
    x0, x1 = (x_face - sentido * prof, x_face + sentido * 0.1)
    descida = Bx(x0, x1, y_piso, topo,
                 zd - (comp + folga) / 2, zd + (comp + folga) / 2)
    za, zb = sorted((z_nominal - comp / 2 - folga / 2, zd + comp / 2 + folga / 2))
    canal = Bx(x0, x1, y_piso, y_piso + alt_canal, za, zb)
    return descida, canal

def ressalto_trava(x0, x1, y_piso, y_aba_atras, z_nominal, comp=5.0,
                   mordida=0.7, recuo=0.2, rampa=2.5, eixo='z'):
    """Rampa que impede a baioneta de recuar depois de travada.

    A aba sobe empurrando e cai atrás da face a pique. Sem ela, a carga de
    trabalho que fecha a trava também a reabre quando alivia.

    `y_aba_atras` é a altura do canto de TRÁS da aba na posição travada, não o
    piso do canal. Numa peça inclinada os dois não coincidem: com 2° e 5 mm de
    aba o canto de trás já está 0,17 mm acima do da frente, e medir a rampa pelo
    piso entrega metade da mordida que você pensou ter dimensionado.

    A altura total tem que caber na folga vertical do canal — a aba precisa
    subir a rampa inteira para passar. Deixe ~30% de margem."""
    from lib3d import RESSALTO
    alt = (y_aba_atras - y_piso) + mordida
    pico = z_nominal + comp / 2 + recuo
    return RESSALTO(x0, x1, y_piso, alt, pico, pico + rampa, eixo=eixo)

# ---------------------------------------------------------------- forquilha
def forquilha(xc, esp_montante, y0, y1, z0, z1, lamina=3.0, folga=0.3):
    """Duas lâminas que abraçam um montante. Impede rotação e racking.

    Precisa existir em cima e embaixo do montante: com uma só, a outra ponta
    fica em balanço e o conjunto inclina.
    """
    d = esp_montante / 2 + folga
    return [Bx(xc + s * d, xc + s * (d + lamina), y0, y1, z0, z1) for s in (+1, -1)]

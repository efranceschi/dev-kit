"""Varredura exaustiva do conjunto montado.

As outras verificações conferem pares escolhidos a dedo. Esta monta o conjunto
inteiro e testa TODOS os pares — é a única que pega o par que ninguém pensou em
conferir, que é justamente onde o erro sobrevive.

Além da sobreposição, faz duas perguntas que nenhum teste de encaixe faz:

  * cada peça sai da impressora num pedaço só?
  * a peça móvel tem apoio embaixo, ou só trava contra sair?

Adapte `montar()` ao seu projeto. O resto vale como está.

    python3 sobreposicao.py           # configuração mínima
    python3 sobreposicao.py 2 2       # 2 módulos em largura, 2 em altura
"""

import itertools
import sys

import numpy as np
import trimesh

TOL = 1.0          # mm3 — abaixo disso é lasca de tangência, não colisão


def T(m, dx=0.0, dy=0.0, dz=0.0):
    m = m.copy()
    m.apply_translation((dx, dy, dz))
    return m


def M(dx=0.0, dy=0.0, dz=0.0):
    m = np.eye(4)
    m[:3, 3] = (dx, dy, dz)
    return m


def vol(a, b):
    try:
        c = trimesh.boolean.intersection([a, b])
        return abs(c.volume) if c is not None and len(c.faces) else 0.0
    except Exception:
        return 0.0


# --------------------------------------------------------------------------
# ADAPTE: devolva [(nome, malha já posicionada no referencial de montagem)]
# para o conjunto inteiro, incluindo todas as repetições de cada peça.
# Os nomes aparecem no relatório — use "PF p0 a1", "BX esq z26", algo que
# permita achar a instância culpada sem contar no dedo.
# --------------------------------------------------------------------------
def montar(N=1, A=1):
    raise NotImplementedError('descreva aqui o conjunto montado')


def encosta(a, b, folga=0.05):
    """Caixas envolventes se tocam? Pré-filtro barato antes do booleano.

    Sem ele a varredura vira O(n²) de operações booleanas e um conjunto de 40
    peças leva minutos. Com ele, a maioria dos pares morre numa comparação de
    seis números."""
    la, ha = a.bounds
    lb, hb = b.bounds
    return np.all(la - folga <= hb) and np.all(lb - folga <= ha)


def varrer(pecas):
    pares = [(i, j) for i, j in itertools.combinations(range(len(pecas)), 2)
             if encosta(pecas[i][1], pecas[j][1])]
    print(f'{len(pecas)} peças · {len(pecas)*(len(pecas)-1)//2} combinações · '
          f'{len(pares)} com caixas que se tocam')
    achados = []
    for i, j in pares:
        v = vol(pecas[i][1], pecas[j][1])
        if v > TOL:
            c = trimesh.boolean.intersection([pecas[i][1], pecas[j][1]])
            achados.append((pecas[i][0], pecas[j][0], v,
                            np.round(c.bounds, 1).tolist()))
    print()
    if not achados:
        print(f'nenhuma sobreposição acima de {TOL} mm3')
    for na, nb, v, b in sorted(achados, key=lambda x: -x[2]):
        print(f'  {na:14} x {nb:14} {v:8.1f} mm3   caixa {b}')
    return achados


def pedacos(pecas):
    """Peça com corpo solto no meio do ar.

    Um ressalto apoiado numa face que um corte posterior apagou continua no
    arquivo, continua estanque, e ainda aparece nos testes de encaixe como se
    segurasse alguma coisa — mas não sai da impressora. Só contando os corpos
    de cada peça isso aparece.

    Conte apenas os corpos de volume positivo: vazios internos fechados
    aparecem como corpos de volume negativo e são legítimos."""
    print()
    print('corpos soltos dentro de cada peça:')
    vistas, mau = set(), False
    for nome, m in pecas:
        k = nome.split()[0]
        if k in vistas:
            continue
        vistas.add(k)
        soltos = [c for c in m.split(only_watertight=False) if c.volume > 0]
        if len(soltos) != 1:
            mau = True
            for c in sorted(soltos, key=lambda c: c.volume)[:-1]:
                print(f'  {k}: fragmento de {c.volume:.1f} mm3 em '
                      f'{np.round(c.bounds[0], 1).tolist()}   SOLTO')
    if not mau:
        print('  nenhuma: todas as peças saem num pedaço só')


def apoio(movel, mundo, folga_esperada=0.6, eixo=1):
    """A peça móvel afunda?

    Travar contra sair e ter apoio embaixo são coisas diferentes, e é fácil
    acertar uma e errar a outra: se a estrutura fixa é reta e a peça móvel é
    inclinada, as travas de um extremo saem da faixa de material do outro. O
    resultado passa em todo teste de encaixe e mesmo assim cede na carga."""
    print()
    d = [0.0, 0.0, 0.0]
    encontrou = None
    for passo in (0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 2.0, 4.0):
        d[eixo] = -passo
        if vol(T(movel, *d), mundo) > TOL:
            encontrou = passo
            break
    ok = encontrou is not None and encontrou <= folga_esperada
    print(f'a peça móvel afunda até encostar em '
          f'{encontrou if encontrou else ">4"} mm   '
          f'{"ok" if ok else "FALHA — sem apoio vertical"}')


def travas(movel, mundo, pontos, subir, rotulo='trava'):
    """Ponto a ponto, nunca o total.

    Quatro travas somadas continuam com número bonito quando uma delas está
    solta. Foi exatamente assim que uma passou despercebida: o total dizia
    5,61 mm3 e a última trava valia zero."""
    print()
    print(f'{rotulo} ao levantar, ponto a ponto:')
    alto = T(movel, 0, subir, 0)
    for nome, caixa in pontos:
        v = vol(trimesh.boolean.intersection([alto, caixa]), mundo)
        print(f'  {nome:16} {v:7.2f} mm3   {"ok" if v > TOL else "SOLTA"}')


if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    A = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    print('=' * 72)
    print(f'SOBREPOSIÇÃO NO CONJUNTO MONTADO — {N} x {A}')
    print('=' * 72)
    pecas = montar(N, A)
    varrer(pecas)
    pedacos(pecas)

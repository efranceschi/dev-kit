# Validação

O modelo 3D mente com facilidade. Duas peças desenhadas como cilindros
sobrepostos parecem encaixar; um pino horizontal parece entrar num furo
horizontal. Só a medição pega isso.

Rode as oito famílias abaixo antes de exportar. Use `scripts/verificar.py` para
as famílias A–G e `scripts/sobreposicao.py` para a H.

**Comece pela H.** As famílias A–G conferem pares escolhidos a dedo, e é a
escolha que falha: o erro sobrevive justamente no par em que ninguém pensou. A H
monta o conjunto inteiro e testa todos, então é ela que descobre o que as outras
não sabiam procurar. As outras continuam necessárias — medem sentido, trajeto e
espelhamento, coisas que uma varredura de volume não enxerga.

## A. Interferência na posição final

Para cada par de peças que se tocam, monte nas posições reais e meça o volume da
interseção. Deve ser zero, ou poucos mm³ de resíduo explicável.

```python
c = trimesh.boolean.intersection([a, b])
volume = abs(c.volume) if c is not None and len(c.faces) else 0.0
```

**Resíduos pequenos têm causa.** Uma lasca de 0,5 mm³ com 0,08 mm de espessura
costuma ser uma peça inclinada cujo bloco reto tangencia um canto. Meça a caixa
envolvente da interseção antes de decidir se importa: abaixo da altura de camada
não afeta nada, mas vale registrar em vez de ignorar.

## B. Encosto e resistência à separação

Interferência zero **também acontece quando as peças estão longe uma da outra**.
Aproximar não basta como prova de encaixe.

- **Encosto:** aproxime a peça B de A em 1,5 mm na direção da montagem. Se
  estavam em contato, aparece interferência.
- **Resistência à separação:** afaste 1,5 mm na direção em que a junta deve
  travar. Num rabo-de-andorinha engatado, afastar causa interferência, porque a
  ponta larga do macho não passa pela boca estreita do soquete.

O passo importa: 0,6 mm pode ser menor que a folga axial da junta e dar falso
negativo. Use 1,5 mm e ajuste se a junta for muito justa.

## C. Caminho de inserção

**A verificação mais esquecida, e a que pega os erros mais caros.** Caber na
posição final não prova que existe trajeto até lá.

Varra a aproximação em ~22 posições e acuse qualquer uma que colida:

```python
def caminho(fixa, movel, passo, n=22, tol=0.5):
    ruins = []
    for k in range(n, 0, -1):
        d = [c * k / n for c in passo]
        if volume_intersecao(fixa, T(movel, *d)) > tol:
            ruins.append(round(k / n, 2))
    return ruins
```

Faça isso para toda junta: peça descendo sobre outra, segmento aproximando do
vizinho, módulo entrando entre montantes.

O sintoma típico de falha é colidir em **todas as posições intermediárias e
liberar só na cota zero** — a peça só existiria montada. A causa costuma ser uma
aba ou parede que chega até o plano da junta e bloqueia a passagem de uma
saliência do vizinho. A correção é recuar essa parede alguns milímetros antes do
plano, abrindo o corredor.

## D. Sabotagem com peça espelhada

Substitua uma peça pela sua versão **espelhada** (não girada) e confirme que o
conjunto rejeita.

```python
def espelhaX(m):
    m = m.copy(); m.apply_transform(np.diag([-1.0, 1.0, 1.0, 1.0]))
    m.invert()          # sem isso as normais ficam invertidas
    return m
```

O critério não é colisão — uma junta auto-acoplável espelhada normalmente
**não colide**, apenas deixa de engatar. Meça a resistência à separação: na
versão correta ela é dezenas de mm³, na espelhada é zero.

Isso prova duas coisas: que a peça gerada está na mão certa, e que o encaixe
distingue girar de espelhar.

## E. Gravação

Confirme que o texto existe nas duas faces, com a mesma área, e que cada face
lê corretamente do seu próprio lado.

Amostre pontos numa grade e classifique como "gravado" o que está **fora do
material junto à face e dentro dela um pouco mais fundo** — comparar só a
ocupação pega os vazios da treliça e dá falso negativo.

```python
raso  = pontos em (face − 0,25 mm)
fundo = pontos em (face − 2,0 mm)
gravado = (~contains(raso)) & contains(fundo)
```

Compare **área** e **posição do centro**, não igualdade de bitmap: com traço de
1,2 mm e grade de 0,25 mm, o espelhamento desloca a amostragem e o XOR acusa
50% de divergência numa gravação perfeita. A face espelhada deve ter o centro
refletido em torno da cota nominal, não coincidente.

Se preferir a prova visual, renderize a grade em ASCII invertendo os eixos como
cada observador vê. É rápido e não deixa dúvida.

## F. Imprimibilidade

**Sobresaliência.** Classifique as faces pelo ângulo da normal com a horizontal:

```python
ang = np.degrees(np.arcsin(np.clip(-normais[:, 2], -1, 1)))
balanco = area[(ang > 50) & (ang < 89)].sum()      # tolerável
suspensa = area[(ang >= 89) & (centro_z > z0 + 0.4)].sum()   # ponte ou suporte
```

Faces a 60° são autossustentáveis — é o que um pino hexagonal produz e é bom
sinal. Faces planas suspensas são pontes: aceitáveis se curtas e em região não
funcional, problema se estiverem numa superfície de encaixe.

**Área de primeira camada.** Fatie a 0,25 mm acima da base e meça a área da
seção. Abaixo de ~250 mm² numa peça alta, recomende brim. Isso também pega o
erro de uma peça apoiada só em três ressaltos com o corpo no ar.

**Caber na mesa.** Compare as três dimensões com o volume da impressora,
descontando alguns milímetros de margem.

## G. Furos e encaixes livres de cortes vizinhos

Um encaixe pode estar perfeito em isolamento e sair mutilado porque **outro
corte da mesma peça passou perto demais**. É um erro que a montagem virtual não
pega: as peças encaixam no modelo, porque o pino entra num furo que perdeu uma
parede e a interferência continua zero.

Faça as duas verificações. A primeira é barata e roda antes de gerar a malha; a
segunda pega o que a aritmética não previu.

### G1. Faixas em z, antes de modelar

Cada feature ocupa uma **faixa**, não um ponto. Liste a extensão real de cada
uma e cheque a interseção aos pares:

```python
furo  = (z - RAIO_FURO, z + RAIO_FURO)
rasgo = (za - meia_aba - folga, za + avanco + meia_aba + folga)
conflito = not (rasgo[1] < furo[0] or rasgo[0] > furo[1])
```

O engano clássico é raciocinar pelos centros: "a aba está a 6 mm do pino, folga
suficiente". Mas um rasgo em L se estende para trás da aba e para a frente do
avanço, e uma lingueta de emenda avança o próprio comprimento além da junta.
Some as extensões, não as distâncias.

Rode isso para todas as combinações, não só as que você suspeita. Quando um
conflito aparece, costuma aparecer em todas as estações de uma vez — é arranjo,
não acidente.

### G2. Parede do furo, depois de modelar

Meça a fração do anel de material em volta do encaixe que sobreviveu aos cortes:

```python
def parede(peca, z, ri=3.50, ro=4.20, y0=0.5, y1=7.5):
    anel = corta(HEX(ro, y1-y0, 0, y0, z), [HEX(ri, y1-y0+2, 0, y0-1, z)])
    i = trimesh.boolean.intersection([anel, peca])
    return (abs(i.volume) if i is not None and len(i.faces) else 0.0) / anel.volume
```

Abaixo de 97% há uma face faltando. Compare sempre com um furo distante de
qualquer outra feature: ele é a linha de base, e não dá 100% por acaso — a
geometria do anel pode extrapolar a espessura da parede.

**Use anel fino, colado ao furo.** Um anel largo pega a vizinhança e acusa
falha onde só existe um vazio legítimo alguns milímetros adiante. Se o valor der
baixo, subtraia a peça do anel e imprima a caixa envolvente do que sobrou: ela
diz qual corte é o culpado.

### Onde isso morde

Juntas, apoios e travamentos tendem a se aglomerar na mesma região — o meio de
uma peça segmentada costuma ter a emenda, o par de pinos da estação central e
uma aba de piso em menos de 20 mm. Quando essa densidade aparecer, separe por
projeto: mova as features para os vãos livres entre furos, e **derive as cotas
secundárias das primárias** (janelas de alívio calculadas a partir das abas, por
exemplo) para que a próxima mudança não recrie o conflito.

## H. Varredura exaustiva do conjunto montado

Monte o conjunto inteiro, com todas as repetições de cada peça, e meça a
interseção de **todos** os pares. Não os que você suspeita: todos.

```python
pares = [(i, j) for i, j in itertools.combinations(range(len(pecas)), 2)
         if encosta(pecas[i][1], pecas[j][1])]      # pré-filtro por caixa
```

O pré-filtro por caixa envolvente é o que torna isso viável: num conjunto de 40
peças, 700 combinações caem para ~120 booleanos.

Dê nome a cada instância (`"PF p0 a1"`, `"BX esq z26"`). Quando o relatório
apontar um par, você precisa achar a instância culpada sem contar no dedo, e
precisa ver se o defeito é de uma posição ou de todas.

Rode em mais de uma configuração — 1×1, 2×2, 3×3. Empilhamento e módulo
compartilhado criam vizinhanças que a configuração mínima não tem.

**O que essa família pega que as outras não pegam:** a peça que atravessa outra
numa região onde ninguém imaginou que elas se encontrassem. Num projeto real,
foram 3.234 mm³ entre o piso e a travessa da base — duas peças que nunca se
tocam pelo encaixe, e que por isso nenhum teste escrito à mão tinha comparado.

### H1. Corpos soltos dentro de cada peça

```python
soltos = [c for c in m.split(only_watertight=False) if c.volume > 0]
```

Mais de um corpo positivo significa fragmento no ar. Isso acontece quando você
**une** um elemento a uma face que um corte anterior apagou: o ressalto fica
estanque, aparece nos testes de encaixe como se segurasse algo, e não sai da
impressora.

Conte só os corpos de volume positivo. Vazios internos fechados aparecem como
corpos de volume negativo e são legítimos.

### H2. Apoio vertical da peça móvel

Travar contra sair e ter apoio embaixo são coisas diferentes. Desloque a peça
móvel para baixo em passos e veja em quantos milímetros ela encosta em material:

```python
for passo in (0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 2.0, 4.0):
    if volume_intersecao(T(movel, 0, -passo, 0), mundo) > TOL:
        break
```

Deve encostar dentro da folga nominal do encaixe. Se ela afunda milímetros, a
peça está pendurada.

**A causa é quase sempre estrutura reta contra peça inclinada.** Um banzo reto
de 8 mm não hospeda uma trava que precisa subir 14 mm ao longo do comprimento:
as travas de um extremo saem da faixa de material do outro. O conjunto continua
passando em todos os testes de encaixe, porque as travas que sobraram seguram
contra levantar — só não seguram para baixo.

### H3. Cada trava medida sozinha

Some quatro travas e o número continua bom com uma delas solta. Fatie o conjunto
na região de cada trava e meça uma por uma:

```python
fatia = trimesh.creation.box(extents=(L, H, 14))
fatia.apply_translation((xc, yc, z_da_trava))
v = volume_intersecao(intersecao(movel_levantado, fatia), fixo)
```

Num caso real o total dizia 5,61 mm³ e parecia saudável; medindo uma a uma, a
última valia **zero**.

Quando todas as travas passam a dar exatamente o mesmo número, é sinal de que a
geometria ficou coerente. Valores que variam entre travas iguais denunciam
desalinhamento sistemático — veja a armadilha 3 em `armadilhas.md`.

## Como apresentar

Tabela com uma linha por verificação, valor medido e veredito. O usuário precisa
ver o número, não só "OK" — é o número que permite julgar se um resíduo importa.

Quando um teste falhar, **primeiro confira se o erro é do teste**. Direção de
aproximação trocada, passo pequeno demais, janela de amostragem no lugar errado:
metade dos "problemas" nasce aí. Só depois mexa na peça.

# Visualizador HTML

Um arquivo HTML autocontido, com as malhas embutidas, que roda com dois cliques
e não precisa de servidor. Vale mais que qualquer print: o usuário gira, explode
e entende a montagem sozinho.

## Estrutura

- `three.js` r128 do cdnjs (`https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`).
- **Não use OrbitControls** — não vem no bundle mínimo. Escreva o orbit em ~25
  linhas com eventos de ponteiro. Ver `scripts/previa3d.py`.
- Geometria embutida como JSON no próprio HTML: `pos` (vértices achatados) e
  `idx` (índices). Arredonde para 2 casas. Malhas de alguns milhares de
  triângulos dão arquivos de 200–350 kB, o que é aceitável.
- Instâncias repetidas (seis bases iguais) entram como **matriz de
  transformação**, não como cópia da malha.

## Feche as tags

Um `</script>` esquecido faz o navegador não executar nada e mostrar tela preta,
sem erro visível. Depois de gerar, valide:

```bash
python3 -c "import re,sys; s=open(sys.argv[1]).read(); \
  b=re.findall(r'<script(?![^>]*src)[^>]*>(.*?)</script>', s, re.S); \
  open('/tmp/chk.js','w').write(b[0]); print('fecha:', s.rstrip().endswith('</html>'))" arquivo.html
node --check /tmp/chk.js
```

Inclua também um `<div>` de erro escondido e um `window.addEventListener('error')`
que o exibe — tela preta silenciosa é o pior modo de falha.

## Giro em torno do centro

No three.js a rotação acontece **antes** da posição. Se você aplica o
deslocamento de centralização no mesmo objeto que gira, ele descreve um círculo
em vez de girar no lugar.

Use dois grupos: o interno carrega o deslocamento e fica parado, o externo só
gira.

```js
grupo.position.set(-centro.x, -centro.y, -centro.z);
pivo = new THREE.Group(); pivo.add(grupo); scene.add(pivo);
// anima: pivo.rotation.y += 0.004
```

## Explosão

Um cursor contínuo de 0 a 100%, não um liga-desliga: arrastando devagar dá para
acompanhar o movimento. Cada instância carrega um **vetor de explosão na direção
em que ela é realmente montada** — bases descem, tampas sobem, laterais abrem,
segmentos se separam no comprimento. Isso transforma o controle em explicação.

```js
const M = base.clone();
M.premultiply(new THREE.Matrix4().makeTranslation(e[0]*f, e[1]*f, e[2]*f));
malha.matrix.copy(M); malha.matrixAutoUpdate = false;
```

Elementos que só fazem sentido montados (o conteúdo, as garrafas) somem sozinhos
quando a explosão passa de ~5%.

## Destacar família

Agrupe as peças por família e ofereça um botão por família que deixa as outras
em opacidade 0,1 com `depthWrite = false`. Combinado com explosão parcial, é o
que faz entender onde uma peça se apoia sem perder a referência do resto.

Se houver duas abas (conjunto e peça isolada), o mesmo destaque deve valer nas
duas — o usuário alterna com a família selecionada e vê onde aquilo vai parar.

## Enquadramento fora do painel

O modelo centralizado na tela fica atrás do painel de controles. Desloque o
enquadramento para a área livre, calculando em unidades do modelo e deslocando
ao longo dos **eixos da câmera**, não dos eixos do mundo — senão o
deslocamento muda conforme você gira.

```js
const dir = pos.clone().negate().normalize();
const dx = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0,1,0)).normalize();
const dy = new THREE.Vector3().crossVectors(dx, dir).normalize();
const wpp = (2 * raio * Math.tan(fov/2)) / innerHeight;   // unidades por pixel
const foco = dx.multiplyScalar(-sx*wpp).add(dy.multiplyScalar(sy*wpp));
camera.position.copy(pos).add(foco);
camera.lookAt(foco);
```

`sx` e `sy` são a diferença em pixels entre o centro da tela e o centro da área
livre.

## Celular

- `touch-action: none` no canvas. Sem isso, arrastar para girar rola a página.
- `height: 100dvh` e `overscroll-behavior: none` — resolve o pulo quando a barra
  de endereço aparece e some.
- **Painel como folha deslizante**, abrindo recolhido com só os controles
  essenciais à vista e uma alça para expandir. O enquadramento se ajusta junto.
- Um dedo gira, dois dedos dão zoom. Ignore ponteiros não primários no
  arrastar (`e.isPrimary === false`), senão o segundo dedo continua alimentando
  a rotação durante a pinça.
- Alvos de toque com no mínimo 42 px, e o botão do cursor em 24 px.
- Esconda título e subtítulo no celular: custam ~50 px que fazem falta.

## O que mostrar

Duas abas funcionam bem: **conjunto montado com explosão** e **peça
individual escolhida numa lista**. Uma "prancha" com todas as peças espalhadas
lado a lado parece boa ideia e na prática confunde — cada peça fica pequena
demais para se reconhecer.

Na peça individual, ofereça alternar entre **como imprime** e **como monta**.
É a dúvida real no momento em que se tira a peça do berço.

Nunca desenhe um esquema quando a geometria existe. Carregue as malhas dos
próprios STLs — e aí o visualizador também serve de conferência.

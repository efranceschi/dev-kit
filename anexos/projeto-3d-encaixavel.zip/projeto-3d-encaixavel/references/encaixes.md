# Encaixes

Cada junta precisa de um mecanismo de travamento **definido**. "Aperta e segura"
não é mecanismo — é o que se diz quando não se pensou no assunto. Prefira juntas
que a gravidade ou a própria carga de trabalho mantêm fechadas.

- [Rabo-de-andorinha auto-acoplável](#rabo-de-andorinha-auto-acoplável)
- [Pino sextavado](#pino-sextavado)
- [Baioneta em L](#baioneta-em-l)
- [Forquilha](#forquilha)
- [Lingueta de alinhamento](#lingueta-de-alinhamento)
- [Perfil T invertido](#perfil-t-invertido)
- [Gravação de códigos](#gravação-de-códigos)
- [Tabela de folgas](#tabela-de-folgas)

## Rabo-de-andorinha auto-acoplável

Para juntar módulos em fila sem precisar de versões esquerda e direita.

**A ideia:** cada extremidade carrega **meio macho e meio soquete**, divididos ao
longo da profundidade. A metade da frente tem o macho, a de trás o soquete.
Girando o módulo 180° em torno do eixo vertical, o macho vai para a metade de
trás — e encontra o soquete do vizinho.

```
módulo A (como gerado)         módulo B (o mesmo, girado 180°)
  profundidade  0..14: macho     profundidade  0..14: soquete
  profundidade 14..28: soquete   profundidade 14..28: macho
```

Uma peça só atende as duas pontas de uma fila, e um módulo central com essa
junta nas duas extremidades é simétrico consigo mesmo.

**Girar não é espelhar.** Espelhar troca x por −x mas mantém a profundidade;
girar troca as duas. Uma peça espelhada encosta na vizinha e parece montada, mas
os dois machos ficam do mesmo lado e os dois soquetes vazios — sai com um puxão.
Teste isso explicitamente (ver `validacao.md`).

**Direção de inserção.** Um rabo-de-andorinha desliza no próprio eixo e não
resiste a nada nessa direção. Escolha o eixo pelo esforço:

- Junta sob **tração axial** (barra de amarração, viga de topo): rabo
  **vertical**, encaixado de cima. Os flancos se opõem à separação e a gravidade
  mantém assentado.
- Junta que só precisa de **alinhamento** (emenda de peça longa em segmentos):
  rabo **horizontal**, deslizando no comprimento, com 1° de conicidade para
  travar por cunha no fim do curso.

**Conicidade.** A folga axial antes de travar é `folga_total / tan(flanco)`. Um
trapézio de 6→9 mm em 8 mm de profundidade tem flanco de 20,6°: com 0,2 mm por
face, escorrega 1,07 mm antes de opor resistência. Abrindo para 6→11 mm, cai
para 0,64 mm. Prefira o flanco mais aberto.

**Posicione a emenda onde o esforço é axial**, no meio do vão, não sobre o
apoio. Sobre o apoio a junta disputa espaço com pinos e forquilhas, e enfraquece
justamente o ponto mais carregado.

## Pino sextavado

Para empilhar e localizar peças umas sobre as outras.

**Hexágono, não cilindro.** Numa peça alta e fina, impressa deitada, o pino sai
com o eixo paralelo à mesa. A metade inferior de um cilindro tem sobresaliência
de 0° no ponto mais baixo — as primeiras camadas seriam ilhas soltas e a peça
exigiria suporte bem na superfície funcional. Um hexágono com vértice para cima
e para baixo apoia em duas faces a 60°, bem acima do limite de 45°, e o topo
vira vértice em vez de ponte.

Oriente os vértices no eixo que vira a vertical na impressão.

**Haste reta com ponta chanfrada, não cone.** Um cone trava onde o diâmetro
casa, e isso acontece a poucos milímetros da base: o engate fica curto e, pior,
todas as folgas de furo travam no mesmo lugar — a escada de calibração perde o
sentido porque todas as posições parecem iguais. Uma haste reta de 6 mm mais
2 mm de ponta cônica dá entrada fácil, engate longo, e aí a diferença entre
furos vizinhos se sente no dedo.

**Dois pinos por sapata**, afastados, em vez de um. Impede rotação e, se a
emenda de um segmento cair ali, um pino de cada lado prende a junta.

## Baioneta em L

Para prender uma peça que desce na vertical e precisa travar contra
levantamento, sem parafuso.

**Movimento:** desce no rasgo vertical até o fundo, avança na horizontal, e a
aba corre sob um lábio.

**Escolha o sentido do avanço a favor da carga.** Se a peça sofre atrito
permanente numa direção, faça a trava engatar nessa mesma direção — a carga de
trabalho mantém a junta fechada, e quanto mais carregada, mais firme.

**Geometria.** Modele com a **posição travada sendo a nominal** e a descida
deslocada. O contrário deixa a peça montada fora do lugar por todo o curso de
avanço.

```
rasgo de descida:  centrado em (posição nominal + avanço)
canal de trava:    de (nominal − meia aba) até (descida + meia aba)
lábio:             o que sobra de material acima do canal
```

O avanço precisa ser maior que o comprimento da aba, senão ela não sai de baixo
do rasgo aberto.

**Folga generosa:** 0,6 a 0,8 mm. É encaixe de montagem, não de precisão.
Apertar aqui não ganha nada e trava a montagem.

### Ressalto de travamento

A baioneta trava contra levantar, mas não contra **recuar**: se a carga alivia,
a peça volta pelo caminho por onde entrou. Ponha uma rampa no canal, logo atrás
da posição travada. A aba sobe empurrando e cai atrás da face a pique — dá um
estalo, e é o estalo que confirma a montagem para o usuário.

Duas regras de dimensionamento, ambas aprendidas errando:

- **Meça a rampa contra o canto da aba, não contra o piso do canal.** Numa peça
  inclinada os dois não coincidem: 2° com 5 mm de aba põem o canto de trás
  0,17 mm acima do da frente, e somando a folga de baixo você entrega metade da
  mordida que pensou ter projetado.
- **A altura total tem que caber na folga vertical do canal**, porque a aba
  precisa subir a rampa inteira para passar. Deixe ~30% de margem. Mordida de
  0,7 mm é firme e ainda monta com a mão.

Use `scripts/encaixes.py::ressalto_trava`.

### Quando a peça móvel é inclinada e a estrutura é reta

Este é o caso que mais custou. Se a peça móvel sobe ao longo do comprimento (uma
pista em rampa) e a estrutura que a segura é reta (um banzo horizontal de altura
fixa), **a profundidade da aba não pode ser constante**. Com profundidade fixa,
as abas de um extremo saem da faixa de material do outro: num extremo ficam
acima do banzo, no outro ficam abaixo dele, penduradas no ar.

O resultado passa em todos os testes de encaixe, porque as abas que sobraram
continuam travando contra levantar. Só não há apoio embaixo, e a peça cede na
carga.

A correção:

```python
prof = min(PROF_MAX, altura_da_rampa(z) - APOIO_MINIMO)
```

A profundidade acompanha a rampa até o limite da parede da peça móvel; onde ela
satura, um montante local na estrutura devolve o lábio por cima. E escreva as
duas cotas — a da aba e a do canal — numa função só, lida pelas duas peças.

## Forquilha

Duas lâminas verticais que abraçam a espessura de um montante.

Pinos impedem deslizamento; forquilhas impedem **rotação**, e é por elas que a
ligação resiste ao balanço lateral. Sem forquilha, montante e base formam uma
articulação disfarçada e a estrutura vira um paralelogramo.

Folga de 0,3 mm por face, comprimento de 15 a 20 mm.

**Precisa haver forquilha em cima e embaixo.** Um quadro fechado só resiste ao
racking com as duas extremidades do montante engastadas. Com uma só, a outra
ponta fica em balanço e o conjunto inclina quando você encosta.

## Lingueta de alinhamento

Quando duas metades de uma peça longa já estão presas individualmente por outros
encaixes, a emenda não precisa de rabo-de-andorinha: basta uma lingueta
retangular que impeça desalinhamento lateral e vertical.

Use **linguetas nas bordas**, não um painel atravessando a largura. O painel
custa muito material e não acrescenta rigidez onde importa.

## Perfil T invertido

Para trilhos, guias e qualquer elemento que precisa de rigidez à flexão ao longo
do comprimento. Mesa estreita em cima (contato), alma vertical embaixo
(inércia). Gasta menos que montantes discretos e imprime melhor — a alma
contínua está ligada à mesa em todo o comprimento e não vibra.

**Montante vertical só faz sentido se houver piso embaixo dele.** Quando a
arquitetura muda e o piso some, os montantes ficam pendurados no ar. Procure por
isso a cada mudança de arquitetura.

## Gravação de códigos

Baixo relevo de 0,6 mm, letra de 8 mm, traço mínimo de 1,2 mm — duas extrusões,
abaixo disso entope.

**Declare a orientação de leitura por face, não deduza um ângulo.** Um
sinalizador `espelhar=True` passado à mão em cada chamada é onde o erro mora —
mas trocá-lo por um ângulo de rotação só move o erro de lugar. Declare os dois
vetores que descrevem a intenção: para onde o texto cresce e para onde aponta o
alto da letra. A matriz de rotação sai deles, com a terceira coluna sendo o
produto vetorial.

A regra que gera a tabela: para quem olha uma face, a direita é
`(direção do olhar) × (para cima)`. Errar o sentido desse produto espelha o
texto, e o modelo 3D não acusa nada — só a peça impressa.

| Face | Texto cresce para | Alto da letra |
|---|---|---|
| +x | −z | +y |
| −x | +z | +y |
| +y (lido da frente, em −z) | −x | +z |
| +z | +x | +y |
| −z | −x | +y |

**Grave nas duas faces** quando a peça for reversível: o módulo da ponta direita
é o da esquerda girado, e com uma gravação só metade das peças montadas fica de
cabeça para baixo.

**Verifique se há material onde você gravou.** Numa peça em treliça, a altura
central costuma ser vazio entre montantes. Meia letra gravada no ar é pior que
nenhuma. Confira contra a geometria, não contra a cota nominal.

**Seta só em peça com sentido definido.** Numa peça reversível a seta indica um
sentido que não existe e cria dúvida na montagem.

## Tabela de folgas

Ponto de partida para PETG a 0,2 mm de camada e 3 perímetros. Calibre sempre.

| Encaixe | Folga | Observação |
|---|---|---|
| Pino em furo | 0,00 a 0,05 mm no diâmetro | linha-a-linha costuma dar aperto firme |
| Rabo-de-andorinha | 0,20 mm por face | escada de 0,15 / 0,20 / 0,25 |
| Baioneta | 0,60 a 0,80 mm | encaixe de montagem |
| Forquilha sobre montante | 0,30 mm por face | |
| Lingueta | 0,20 mm por face | |

Peça impressa deitada tem furo horizontal, com barriga no topo — fecha mais que
o furo vertical. Calibre pelo **pior caso**.

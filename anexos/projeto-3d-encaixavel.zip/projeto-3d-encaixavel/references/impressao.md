# Impressão, materiais e calibração

## Material

**PETG** é o padrão para peças estruturais encaixáveis. Mais tenaz que PLA, não
fica quebradiço no frio (importante em geladeira ou ambiente externo), tolera
umidade e condensação, e desliza melhor. A contrapartida é ser um pouco mais
chato de fatiar — cordas e escorrimento.

**PLA** serve para protótipo e para peça de bancada em ambiente estável. Evite
em qualquer coisa que sofra impacto ou frio: um batente de PLA a 5 °C racha
onde o PETG cede.

**ABS/ASA** só se houver sol direto ou calor. Exige câmara fechada e contrai
muito, o que estraga folga de encaixe calibrada.

**TPU** não serve para encaixe estrutural, mas é bom para almofadas
antiderrapantes coladas na base.

## Parâmetros

| Parâmetro | Valor | Por quê |
|---|---|---|
| Altura de camada | 0,2 mm | compromisso entre tempo e definição de encaixe |
| Perímetros | 3 | 1,2 mm de parede sólida onde importa |
| Preenchimento | 0% | o vazio é geométrico, no desenho da treliça |
| Suporte | nenhum | se precisar, a orientação ou a geometria estão erradas |

Preenchimento zero com 3 perímetros é a combinação que dá peça leve e rígida
quando a geometria já é vazada. Se você precisou de infill, provavelmente
desenhou blocos maciços onde caberia nervura.

## Orientação na mesa

**Escolha por intenção, não por busca automática.** Um algoritmo que minimiza
altura escolhe apoios absurdos — já mandou imprimir um piso de 410 mm em pé,
apoiado na ponta. Os critérios, em ordem:

1. Maior face plana na mesa.
2. Saliências apontando para cima.
3. Superfície funcional longe de ponte e de suporte.
4. Linhas de camada transversais ao esforço de flexão.

**Exporte o STL já na orientação de impressão**, apoiado em Z=0. O usuário não
deve precisar girar nada, e girar no fatiador é como se perde a orientação
correta do encaixe.

**Superfície coplanar não exige ser a primeira camada.** Trilhos que terminam na
mesma camada saem coplanares do mesmo jeito, porque Z é o eixo mais preciso da
impressora. Se pôr a superfície funcional na mesa obriga a apoiar a peça num
batente, é pior o remédio — vire para cima.

**Confira o apoio depois de escolher.** Meça a área da seção a 0,25 mm da base.
Uma peça que apoia só em ressaltos e deixa o corpo a 10 mm no ar passa em todos
os testes geométricos e falha na impressora.

## Corpos de prova de calibração

Nenhuma impressora entrega a medida do desenho: furo sai menor, pino sai maior,
por um a três décimos. Esse número é da máquina, do filamento e da temperatura —
ninguém pode fornecê-lo, tem que ser medido uma vez.

### Escada de folgas, não tentativa e erro

Com um encaixe só, não há referência: não dá para saber se está apertado porque
a folga é pequena ou porque aquele é o aperto certo. Com cinco lado a lado, a
comparação é imediata e acerta na primeira impressão.

**Um macho solto por tipo de encaixe, uma régua fêmea por tipo.** Nunca um macho
por posição: com cinco pinos numa régua e cinco furos na outra, os cinco pares
entram ao mesmo tempo e você não consegue testar um isoladamente.

### Dimensionar para gastar pouco

Um jogo completo de calibração deve caber em torno de 25 cm³, uns 30 g. Se
passar muito disso, há material sobrando.

- **Aberturas viradas para a frente**, não para a lateral. Com a cavidade
  abrindo de lado, cada bloco precisa de espaço livre ao lado para a pega do
  macho passar, e esse vazio vira material. Abrindo para a frente, os blocos
  encostam um no outro.
- **Altura mínima.** O que se mede é folga, não resistência. Corte tudo que não
  participa do encaixe.
- **Mantenha o comprimento de engate.** Um furo raso tem menos atrito e faz você
  julgar tudo mais frouxo do que é, escolhendo um ajuste apertado demais.
- **Marque por entalhe, não por número gravado.** Número em baixo relevo obriga
  uma parede frontal de 2 mm e engorda a peça inteira. Um entalhe é um corte:
  tira material em vez de exigir material. Uma ranhura para a posição 1, duas
  para a 2, e você conta com o dedo.

### Orientação dos corpos de prova

**Cada macho e cada régua sai na mesma orientação em que aquele encaixe é
impresso na peça real.** Encaixe de teste impresso para cima teria o perfil
formado camada a camada em Z, o eixo mais preciso — a folga medida sairia melhor
que a real.

Se o mesmo encaixe aparece em duas orientações no conjunto (pino em pé na base e
deitado na coluna), calibre pelo **pior caso**, o deitado.

### Como julgar

- Não entra, ou para no meio: folga pequena, vá para a próxima.
- Entra com pressão firme do polegar, encosta no fundo, não cai quando você vira
  de cabeça para baixo e sacode: é essa.
- Entra fácil e balança ao torcer: folga grande, volte uma.

Entre duas posições boas, fique com a **mais apertada**. Folga individual pequena
vira balanço grande somada em trinta juntas.

### Depois da calibração

O teste mais barato que ainda pega erro é imprimir **uma peça real de cada
família** e encaixá-las. Token de teste mede folga; peça real mede folga **mais**
empenamento, contração e pé-de-elefante — e é numa peça de 200 mm que isso
aparece.

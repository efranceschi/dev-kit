# Armadilhas

Erros já cometidos, em ordem de quanto custa descobri-los tarde. Leia antes de
modelar, e releia antes de exportar.

## 1. Par de peças que ninguém pensou em comparar

**Sintoma:** todas as verificações passam e o conjunto não fecha na bancada.

As verificações de encaixe conferem os pares que se encaixam. Duas peças que
nunca se tocam pelo encaixe podem ocupar o mesmo espaço em outro ponto do
conjunto, e nenhum teste escrito à mão vai compará-las — porque a lista de
testes é feita a partir da lista de encaixes.

Num caso real foram 3.234 mm³ entre o piso de uma pista e a travessa da base,
descobertos só quando passei a montar o conjunto inteiro e testar **todos** os
pares (`validacao.md`, família H). Esta é a verificação com maior relação entre
o que acha e o que custa escrever.

## 2. Peça móvel travada, mas sem apoio embaixo

**Sintoma:** trava em todos os testes, e cede quando você carrega.

Travar contra sair e ter apoio embaixo são coisas diferentes. Se a estrutura
fixa é reta e a peça móvel é inclinada, as travas de um extremo saem da faixa de
material do outro: as que sobraram continuam segurando contra levantar, e
ninguém segura para baixo.

O caso concreto: banzo reto de 8 mm, pista subindo 14,3 mm no comprimento, travas
a 16 mm dos trilhos. Na frente, as travas ficavam **abaixo** da coluna, no ar —
o segmento dianteiro pendurava pela emenda. A correção foi a profundidade da
trava acompanhar a rampa até o limite da parede, e um montante local segurar no
outro extremo. Teste com `validacao.md`, H2.

## 3. Duas peças calculando a mesma cota

**Sintoma:** a folga fica boa de um lado e some do outro.

Quando a peça A e a peça B calculam cada uma a posição do mesmo encaixe, basta
um termo entrar num cálculo e não no outro. Uma inclinação de 2° com braço de
13,75 mm desloca 0,48 mm — numa folga de 0,4 mm, é a diferença entre encaixar e
raspar numa parede só, com folga do dobro na outra.

**Regra:** uma função devolve as cotas do encaixe, e as duas peças leem dela.
Nunca repita a conta, nem "porque é simples". O sintoma de que já aconteceu é
travas iguais medindo valores diferentes.

## 4. Corpo solto que continua passando nos testes

**Sintoma:** o STL é estanque, o encaixe mede certo, e a peça sai incompleta.

Se você **une** um elemento a uma face que um corte anterior apagou, ele fica
boiando. Continua no arquivo, continua estanque, e ainda aparece nos testes de
encaixe segurando coisa nenhuma — foi assim que um ressalto de travamento
"funcionou" em três verificações seguidas sem existir fisicamente.

Conte os corpos de volume positivo de cada peça (`validacao.md`, H1). Vazios
internos fechados dão corpo de volume negativo e são legítimos.

## 5. Encaixe que não tem caminho de montagem

**Sintoma:** todas as verificações passam, mas a peça não entra.

Uma aba, parede ou saliência que chega até o plano da junta bloqueia a passagem
de uma saliência do vizinho durante a aproximação. Na posição final elas ficam
empilhadas e não interferem; em toda posição intermediária, colidem.

Só o **teste de caminho** (`validacao.md`, seção C) pega isso. A correção é
recuar a parede uns 9 mm antes do plano da junta.

## 6. Pino horizontal em furo horizontal cego

**Sintoma:** o manual manda "baixar a peça e encaixar", e é fisicamente
impossível.

Um pino horizontal não entra descendo na vertical. Ou o encaixe vira baioneta —
desce num rasgo vertical e avança — ou muda de eixo. Descobri isso só ao simular
a montagem; o desenho parecia perfeito porque pino e furo eram cilindros
sobrepostos na posição final.

## 7. Cilindro deitado sem suporte

**Sintoma:** a fatia mostra ilhas soltas nas primeiras camadas do pino.

Peça alta e fina imprime deitada, e aí todo pino fica com o eixo paralelo à
mesa. A metade de baixo de um cilindro tem 0° de sobresaliência. Use hexágono
com vértice para cima e para baixo. Vale para a peça real, não só para o corpo
de prova.

## 8. Peça espelhada em vez de girada

**Sintoma:** encosta, parece montada, sai com um puxão.

Numa junta auto-acoplável, espelhar **não** colide — apenas deixa de engatar.
Nunca espelhe um arquivo no fatiador, nem "para caber melhor na mesa". Teste
com a sabotagem de `validacao.md`, seção D.

## 9. Gravação caindo no vazio

**Sintoma:** lê-se metade do código, ou nada.

Em peça vazada, a altura central costuma ser vão entre montantes, e a viga de
borda costuma ter janelas de alívio. Texto posicionado pela cota nominal cai ali.
Posicione sobre região cheia e confirme contra a geometria.

## 10. Orientação de impressão escolhida por algoritmo

**Sintoma:** peça de 400 mm saindo em pé, apoiada na ponta.

Minimizar altura não é o critério. Escolha por intenção e depois **meça a área da
primeira camada** — isso pega também a peça que apoia só em três ressaltos com o
corpo a 10 mm no ar.

## 11. Peça que atravessa a largura do conjunto

**Sintoma:** acrescentar um módulo exige reimprimir peças que já existiam.

Qualquer elemento cujo tamanho dependa do número de módulos quebra a
extensibilidade. Modularize por vão, com nó compartilhado. Teste 1×1, 1×2, 2×1 e
2×2 antes de detalhar.

## 12. Rabo-de-andorinha na direção errada do esforço

**Sintoma:** a junta abre sozinha sob carga.

O rabo desliza no próprio eixo e não resiste nessa direção. Numa barra de
amarração, o esforço é axial — então o rabo tem que ser **vertical**, encaixado
de cima, não deslizando no comprimento.

## 13. Ângulo ou folga chutados por segurança

**Sintoma:** o projeto fica alto, pesado ou não cabe, sem necessidade.

Um ângulo 10× maior que o calculado parece prudente e custa o projeto inteiro em
altura. Calcule, diga que calculou, e ofereça o ajuste em vez da margem.

## 14. Montante pendurado no ar

**Sintoma:** elementos verticais que não tocam nada embaixo.

Resíduo de arquitetura anterior: existia um piso, o piso virou outra coisa, os
montantes ficaram. A cada mudança de arquitetura, procure o que perdeu o apoio.
E lembre que a função que eles exerciam ainda precisa existir, provavelmente em
outra direção.

## 15. Teste de encaixe com todos os pares na mesma régua

**Sintoma:** não dá para testar uma folga isoladamente.

Cinco pinos numa régua e cinco furos na outra entram todos ao mesmo tempo. Um
macho solto por tipo, uma régua fêmea por tipo.

## 16. Cone no lugar de haste reta no corpo de prova

**Sintoma:** todas as posições da escada parecem iguais.

Um cone sempre acha um ponto onde trava. A escada de folgas só funciona com
haste reta e ponta chanfrada.

## 17. HTML sem as tags de fechamento

**Sintoma:** tela preta, sem erro no console.

`</script>`, `</body>`, `</html>`. Valide o fechamento e a sintaxe do JS com
`node --check` antes de entregar.

## 18. Giro do visualizador em torno da origem

**Sintoma:** o modelo descreve um círculo em vez de girar no lugar.

No three.js a rotação vem antes da posição. Separe o grupo que desloca do grupo
que gira.

## 19. Enquadramento atrás do painel

**Sintoma:** no celular, metade do modelo fica escondida.

Desloque o enquadramento para a área livre, ao longo dos eixos da câmera.

## 20. Teste de comparação rigoroso demais

**Sintoma:** falha reportada onde a peça está certa.

Comparar bitmaps de gravação com XOR acusa 50% de divergência numa gravação
perfeita, porque a grade de amostragem cai diferente depois do espelhamento.
Quando um teste falhar, confira primeiro se o erro é do teste: direção de
aproximação trocada, passo pequeno demais, janela de amostragem no lugar errado.

## 21. Número ditado que não fecha com a física

**Sintoma:** uma cota absurda passa despercebida.

"16 mm" para uma garrafa de 200 ml é 160 mm. Quando um valor não fecha, diga e
peça confirmação antes de modelar em cima dele.

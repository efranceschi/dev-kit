# Manual de montagem

Um HTML com folha de estilo de impressão, que vira PDF limpo pelo navegador.
Quem monta está com a peça na mão, não com o mouse.

## Nomenclatura das peças

Grave o **código de tipo**, não um número por cópia. Peças do mesmo tipo são
intercambiáveis: numerar cada cópia obrigaria a fatiar dezenas de arquivos onde
há oito, e a numeração não diria nada na montagem. A posição vai no manual.

Monte o código em duas letras: **família + posição**.

- Primeira letra única por família, e visualmente distinta: `B`, `K`, `L`, `P`
  servem; evite `I`, `O`, `Q`, e evite duas famílias com a mesma inicial.
- Segunda letra indica a metade ou o segmento: `E`/`D` para peças partidas na
  largura, `F`/`T` para partidas no comprimento, `X`/`C` para extremidade e
  central.
- Nenhum código deve compartilhar as duas letras com outro.

Explique no manual **por que não há número por cópia** — senão parece descuido.

## Estrutura

```
1  Códigos das peças          tabela + prancha de silhuetas + quantidades por configuração
2  Como cada junta trava      tabela junta → tipo → o que a mantém fechada + folgas
3  Impressão                  parâmetros, orientação, onde fica a gravação
4  Calibração                 corpos de prova, como julgar, o que fazer com o resultado
5  Montagem                   sequência em quadros + passos numerados
6  Conferência final          lista de verificação com caixas
7  Se algo não funcionar      sintoma → causa provável
```

A seção 7 é a que mais se usa e a que mais se esquece de escrever. Cada linha
liga um sintoma observável a uma causa: "a garrafa para sempre no mesmo ponto →
degrau na emenda, lixe o chanfro".

## Passos

Um passo é uma **ação com um critério de sucesso**. Escreva o que conferir antes
de seguir, não só o que fazer.

Passos que não podem faltar:

- **Emendar os segmentos fora do local final.** Emendar dentro do vão é
  desconfortável e impede conferir o alinhamento.
- **Conferir a emenda com a mão** onde houver superfície funcional atravessando
  a junta. Um degrau de um décimo já atrapalha.
- **O movimento não óbvio**, se houver — uma baioneta que precisa avançar depois
  de descer é exatamente o tipo de passo que alguém pula.
- **A etapa que parece decorativa mas não é**, com o motivo explícito. Uma
  travessa de coroamento parece acabamento e é o que segura o esquadro.

Diga também **o que não fazer**: espelhar peça no fatiador, empilhar duas peças
que têm interface compatível mas não são vizinhas na montagem.

## Figuras

### Prancha de silhuetas

Extraia a silhueta **das próprias malhas**, projetando de cima com a peça na
orientação de impressão — é o contorno que a pessoa vê ao tirar do berço, com os
vazios internos no lugar certo. Regenerando o modelo, as figuras acompanham.

```python
from shapely.geometry import Polygon
from shapely.ops import unary_union
v = malha.vertices[:, :2]
u = unary_union([Polygon(v[f]) for f in malha.faces if Polygon(v[f]).area > 1e-6])
u = u.buffer(0.01).buffer(-0.01).simplify(0.25, preserve_topology=True)
```

Converta exterior e interiores em `path` com `fill-rule="evenodd"`. O `simplify`
derruba o SVG de 80 kB para 10 kB sem diferença visível.

Isso resolve o caso mais perigoso: duas peças quase idênticas (um segmento
dianteiro e um traseiro que diferem só na altura de um rasgo). Lado a lado, a
diferença aparece.

### Esquemas

Desenhe à mão, em SVG, o que a silhueta não mostra: movimento e seção. Três
quadros para um movimento em duas etapas; dois painéis para "por que esta
geometria e não a óbvia".

Use a mesma paleta do documento e `stroke`/`fill` com cores explícitas — o SVG
precisa sobreviver à impressão em papel.

## CSS de impressão

```css
@media print{
  body{background:#fff;font-size:11pt}
  .folha{padding:0;max-width:none}
  h2{break-after:avoid;page-break-after:avoid}
  figure,.passo,.nota,table{break-inside:avoid;page-break-inside:avoid}
}
```

Sem `break-inside: avoid` nas figuras e nos passos, o navegador corta um desenho
ao meio entre páginas.

## Rodapé de configuração

Termine com uma linha listando as cotas que o manual assume: dimensões do objeto
guardado, do vão, ângulo, passos, folgas. É o que permite saber, meses depois,
se o manual na mão corresponde às peças na gaveta.

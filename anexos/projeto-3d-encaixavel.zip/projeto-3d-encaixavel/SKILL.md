---
name: "projeto-3d-encaixavel"
description: "Projeta peças 3D grandes, segmentadas e encaixáveis - do requisito ao STL, com validação automática, visualizador HTML e manual de montagem. Use SEMPRE que o usuário quiser criar, modelar ou imprimir um objeto em 3D que não cabe inteiro na mesa da impressora, que precise ser montado a partir de várias peças, que precise encaixar sem cola ou parafuso, ou que deva ser modular/expansível. Também use para organizadores, suportes, gavetas, prateleiras, dispensers, caixas modulares, sistemas de encaixe, e para qualquer pedido do tipo \"gera o STL\", \"modela essa peça\", \"cria um suporte para X\", mesmo que o usuário não mencione impressão 3D explicitamente."
---

# Projeto 3D encaixável

Metodologia para projetar objetos impressos em 3D que são grandes demais para a
mesa, montados por encaixe e expansíveis por módulos. Cobre o ciclo inteiro:
requisito, princípio mecânico, decomposição em famílias de peça, modelagem
paramétrica, validação automatizada, exportação, calibração, visualizador e
manual.

O ganho não está em modelar bonito. Está em **descobrir os erros antes da
impressão** — porque a peça só revela o problema depois de trinta horas de
extrusora. Mais da metade desta skill é sobre verificação.

## Quando usar cada arquivo

| Preciso de… | Leia |
|---|---|
| Geometria dos encaixes, tolerâncias, quando usar cada um | `references/encaixes.md` |
| O que testar e como, incluindo os testes que ninguém lembra | `references/validacao.md` |
| Material, orientação na mesa, corpos de prova de calibração | `references/impressao.md` |
| Montar o visualizador HTML 3D | `references/visualizador.md` |
| Estrutura do manual e geração das figuras | `references/manual.md` |
| A lista de erros já cometidos — leia antes de modelar | `references/armadilhas.md` |
| Simular a impressão camada a camada (família I) | seção **Simulação de impressão** abaixo |

Os scripts em `scripts/` são para copiar e adaptar, não para importar de fora:

| Script | Para quê |
|---|---|
| `scripts/lib3d.py` | primitivas, booleanos, gravação em baixo relevo, orientação de impressão |
| `scripts/encaixes.py` | geradores dos encaixes — rabo-de-andorinha, pino hexagonal, baioneta, ressalto |
| `scripts/gerador_exemplo.py` | esqueleto de um gerador paramétrico completo |
| `scripts/verificar.py` | famílias A–G: interferência, encosto, caminho, espelhamento, imprimibilidade |
| `scripts/sobreposicao.py` | família H: conjunto inteiro, todos os pares, corpos soltos, apoio vertical |
| `scripts/previa3d.py` | exportação das malhas para o visualizador HTML |
| `simula_camadas.py` (código na seção abaixo) | família I: impressão simulada camada a camada |

## Ambiente

```bash
pip install trimesh manifold3d shapely numpy rtree --break-system-packages
```

`trimesh` com backend `manifold3d` faz operações booleanas confiáveis. OpenSCAD
não costuma estar disponível e não é necessário. `shapely` é usado para perfis
extrudados e para as seções da simulação de camadas; `rtree` é exigido pelo
fatiamento (`section_multiplane`).

## Etapas

### 1. Levantar o envelope, não o detalhe

Pergunte as medidas que **limitam**, não as que descrevem. Para um organizador de
geladeira: profundidade útil da prateleira, vão livre entre prateleiras, largura,
tipo de apoio. Do objeto a ser guardado: diâmetro máximo e comprimento total.

Resista à tentação de pedir o perfil completo do objeto. Na prática o projeto
quase sempre pode ser feito para funcionar com **qualquer** perfil dentro de um
envelope, e isso vale muito mais do que ajustar a uma marca específica. Se você
se pegar pedindo "o diâmetro a cada 10 mm", pare e pense se existe uma solução
auto-adaptável.

Confirme cada número em tabela antes de modelar. Números ditados por voz erram:
"16 mm" para uma garrafa de 200 ml é 160 mm. Quando um valor não fecha com a
física, diga isso e peça confirmação.

### 2. Escolher o princípio mecânico antes da geometria

Calcule, não chute. Exemplos do tipo de conta que decide o projeto:

- Rolamento de cilindro rígido sobre plástico: braço de resistência ~0,2–0,3 mm.
  Com raio de 25 mm dá coeficiente ~0,01, ou seja **menos de 1° já rola**.
- Atrito estático PET sobre PLA: exige ~18–20° para deslizar. Rolar em vez de
  deslizar troca 19° por 6°, e numa pista de 400 mm isso é a diferença entre
  120 mm e 40 mm de desnível.
- Energia para escalar um batente: a peça só tem a altura que caiu. Rolando
  50 mm a 2°, ela ganha 1,75 mm — um batente de 10 mm tem margem de 6×.

Quando chutar por segurança, diga que está chutando e quanto. Um ângulo 10×
maior que o necessário parece prudente e custa o projeto inteiro em altura.

### 3. Decompor em famílias, não em "peça inteira"

Esta é a decisão que determina se o projeto é expansível.

**Separe nó de ligação.** Se a estrutura tem N vãos, não faça N peças completas:
faça N+1 nós (colunas, montantes) e N ligações. Módulos vizinhos compartilham o
nó, e crescer custa 1 peça por vão em vez de 2.

**Teste a extensibilidade cedo**, montando mentalmente as configurações 1×1,
1×2, 2×1 e 2×2. Se alguma exige uma peça nova, a decomposição está errada.
O sintoma clássico: uma peça que atravessa a largura inteira do conjunto. Ela
muda de tamanho quando você acrescenta um módulo.

**Faça as peças de extremidade auto-acopláveis** em vez de criar versões
esquerda e direita. Veja `references/encaixes.md`.

### 4. Modelar paramétrico

Todo o modelo num script Python com as cotas no topo. Copie `scripts/lib3d.py`
e escreva o gerador seguindo `scripts/gerador_exemplo.py`.

Regras que evitam retrabalho:

- **Uma constante por conceito**, nunca um número repetido. Quando a folga
  calibrada mudar, deve ser uma linha.
- **Uma conta por encaixe, lida pelas duas peças.** Se A tem uma saliência e B o
  alojamento, escreva uma função que devolve as cotas e chame-a nas duas. Duas
  contas equivalentes divergem no primeiro termo que entra numa e não na outra —
  uma inclinação de 2° com 13,75 mm de braço desloca 0,48 mm, e a folga é 0,4.
- **Peça plana, inclinação na contraparte.** Se algo precisa ficar inclinado,
  modele-o plano e ponha a inclinação nas cotas dos encaixes do vizinho. Assim
  a peça imprime deitada e a superfície funcional sai coplanar por construção.
- **Cada corte num sólido separado**, unidos numa lista, e um `difference` só
  no fim. Booleano em cadeia é lento e esconde erro.
- **Valide a estanqueidade a cada peça** (`m.is_watertight`).
- **Em parede inclinada, pense no teto de cada cavidade já ao modelar.** Todo
  corte com topo plano numa placa inclinada vira teto com a inclinação da placa
  (ex.: placa a 65° → teto a 25° da mesa). Veja as regras da família I.

### 5. Validar antes de exportar

Rode as nove famílias de teste: as oito de `references/validacao.md` (A–H),
**começando pela varredura exaustiva (H)**, e a **simulação de impressão (I)**
desta skill. Monte o conjunto inteiro e meça todos os pares, em mais de uma
configuração. As demais famílias conferem os pares que você escolheu, e é a
escolha que falha — o erro sobrevive no par em que ninguém pensou.

As verificações que costumam ser esquecidas:

- **Varredura exaustiva do conjunto** — acha a peça que atravessa outra numa
  região onde ninguém imaginou que elas se encontrassem.
- **Apoio vertical da peça móvel** — travar contra sair e ter apoio embaixo são
  coisas diferentes; é possível acertar uma e errar a outra sem que nenhum teste
  de encaixe perceba.
- **Caminho de inserção** — interferência zero na posição final não prova que
  existe trajeto até lá.
- **Sabotagem com peça espelhada** — confirma que o encaixe distingue girar de
  espelhar.
- **Cortes vizinhos** — um furo pode perder uma parede para o rasgo de outro
  encaixe e continuar passando em tudo, porque o pino ainda entra.
- **Simulação de impressão (I)** — obrigatória para todo STL entregue. Um modelo
  com qualquer ILHA no ar está **reprovado** e não pode ser exportado.

E uma regra que vale para toda medida de conjunto: **meça ponto a ponto, nunca
o total**. Quatro travas somadas continuam com número bom quando uma delas está
solta.

### 6. Exportar na orientação de impressão

Os STLs saem prontos para fatiar: maior face na mesa, saliências para cima,
sem suporte. O usuário não deve precisar girar nada. Escolha a orientação **por
intenção**, não por busca automática — um algoritmo que minimiza altura escolhe
apoios absurdos. Veja `references/impressao.md`. Rode a família I **sobre a malha
já na orientação de exportação** — é a orientação que decide o que fica no ar.

### 7. Corpos de prova de calibração

Antes das peças definitivas, gere um jogo mínimo de calibração: um macho solto
por tipo de encaixe e uma régua fêmea com as folgas em escada. Detalhes de
dimensionamento, marcação e orientação em `references/impressao.md`.

### 8. Visualizador e manual

Veja `references/visualizador.md` e `references/manual.md`. Ambos consomem as
malhas reais — nunca desenhe um esquema quando a geometria existe. Use
`flatShading` e cores contrastantes por família: com sombreamento suave, relevos
rasos e paredes finas somem na prévia.

## Simulação de impressão (família I)

Imprima a peça de mentira antes de imprimir de verdade. Fatie a malha **na
orientação de exportação**, em camadas da altura real (0,2 mm), e percorra de
baixo para cima comparando cada camada com a de baixo:

- **ILHA → reprova.** Parte conexa da camada que não toca em nada da camada de
  baixo (tolerância 0,05 mm). É material começando no ar: não imprime, e é o que
  os slicers chamam de *floating* / *floating cantilever*. O modelo só passa com
  **zero ilhas**.
- **BALANÇO → alerta.** Material além de `h·tan(θmax)` da camada de baixo
  (θmax = 55° da vertical → 0,29 mm por camada de 0,2), mas preso a uma parte
  apoiada. Liste cada região com altura, posição e quanto avança por camada.
  Ponte curta presa nas duas pontas e teto a ~25° em cavidade escondida são
  aceitáveis; avise o usuário de cada um, com o tamanho.

Critérios que já erraram e não devem voltar:

- **Não classifique ilha pelo pedaço sem apoio**, e sim pela parte conexa
  inteira da camada. O pedaço além de `d` nunca encosta na camada de baixo por
  construção — testar ele marca balanço comum como ilha, e o contrário esconde
  ilha de verdade.
- **Não use limiar frouxo.** Avanço de 0,45 mm/camada (≈66°) deixou passar um
  teto a 25° inteiro. O limiar é `0,2·tan(55°) ≈ 0,29 mm`.
- **Confira a ilha com um corte transversal** antes de redesenhar: material
  aparecendo numa camada com ±6 mm de vazio embaixo é ilha real.

```python
import numpy as np
from shapely.ops import unary_union
from shapely.geometry import Point

def simular(malha, camada=0.2, theta_max=55.0, tol=0.05, area_min=0.3, nome=''):
    m = malha.copy(); m.apply_translation((0, 0, -m.bounds[0][2]))
    zs = np.arange(camada / 2, m.bounds[1][2], camada)
    secs = m.section_multiplane([0, 0, 0], [0, 0, 1], zs)
    d = camada * np.tan(np.radians(theta_max))
    ant, itens = None, []
    for z, s in zip(zs, secs):
        cam = unary_union(s.polygons_full) if s is not None and len(s.polygons_full) else None
        if cam is None: ant = None; continue
        if ant is None:
            if z > camada: itens.append(('ILHA', z, cam.area, cam.bounds, 0))
        else:
            base = ant.buffer(tol)
            for p in getattr(cam, 'geoms', [cam]):          # parte conexa inteira
                if p.area >= area_min and not p.intersects(base):
                    itens.append(('ILHA', z, p.area, p.bounds, 0))
            sem = cam.difference(ant.buffer(d, join_style=1))
            for p in getattr(sem, 'geoms', [sem]):
                if p.is_empty or p.area < 1.0: continue
                av = max(ant.distance(Point(xy)) for xy in p.exterior.coords)
                itens.append(('balanço', z, p.area, p.bounds, av))
        ant = cam
    ilhas = [i for i in itens if i[0] == 'ILHA']
    print(f"== {nome}: {'REPROVADO' if ilhas else 'APROVADO'} — {len(ilhas)} ilha(s)")
    return ilhas, itens   # agrupe camadas vizinhas por região antes de relatar
```

### Como não criar ilhas — regras de geometria

- **Cunha pendurada (∨).** Material entre duas faces que sobem a partir da mesma
  aresta começa no ar nessa aresta. Aparece quando um telhado em V atravessa a
  espessura de uma parede e a água de trás sai para o vazio, ou quando o fundo
  de um rebaixo encontra o teto chanfrado de outra cavidade. Um telhado em V só
  é seguro se as duas águas terminarem em paredes que continuam para baixo.
- **Abertura que atravessa parede inclinada**: faça o topo pontudo **no plano da
  parede** (gota a 45°), não um telhado atravessando a espessura. As faces da
  gota ficam a ~50° da mesa e se fecham numa costura apoiada dos dois lados.
- **Teto preso a uma parede que continua para baixo** é balanço, não ilha. Um
  túnel aberto nas duas pontas **e** atrás não tem onde prender o teto: feche
  uma das saídas ou reduza a abertura de trás a uma janela curta (ponte presa
  nas duas pontas).
- **Barra sobre um vão (lábio, beiral) só imprime como ponte presa nas duas
  pontas.** Nunca deixe uma das pontas abrir para outro vazio.
- **Película residual de corte** (ex.: corte parando 0,05–2 mm antes de uma
  face) vira tira fina pendurada: leve o corte até a face ou 0,05 mm além.
- Depois de cada correção, **rode a família I de novo** — uma correção de teto
  costuma criar cunha em outro lugar.

## Lista de materiais

Derive a lista da fórmula, não da contagem. Para um arranjo de N módulos em
largura por A andares, com nó compartilhado:

```
nós            (N+1) × A × (segmentos por nó)
ligações        N × A × (segmentos por ligação)
bases           por estação de apoio, N+1 sapatas
```

Apresente sempre como tabela com a fórmula ao lado do valor, mais uma coluna por
configuração comum. O usuário precisa saber quanto custa crescer, não só quanto
custa o que ele pediu.

Some o volume sólido das malhas e converta: PETG ≈ 1,27 g/cm³, PLA ≈ 1,24 g/cm³.
Com 0% de preenchimento e 3 perímetros, o filamento real fica em torno de 70% do
volume sólido em peças de parede grossa, e ~100% em nervuras finas. Avise quando
o total passar de meio quilo — muda a decisão do usuário.

## Auto-aprendizado

Esta skill deve crescer com o uso. Quando durante um projeto surgir um
aprendizado novo — um encaixe que falhou de um jeito inédito, uma verificação
que pegou algo, uma técnica melhor — **proponha a atualização e peça confirmação
antes de escrever**:

> "Isso é um aprendizado novo: [o que aconteceu, a causa, a correção].
> Quer que eu acrescente à skill, em `references/[arquivo]`?"

Só edite depois do "sim". Ao editar:

- Acrescente em `references/armadilhas.md` se for um erro a evitar, com a
  causa e o sintoma — o sintoma é o que permite reconhecer o problema de novo.
- Acrescente na referência temática se for técnica nova.
- Não reescreva o que já está lá para "melhorar a redação". Só mude o que o
  aprendizado tornou errado ou incompleto.
- Mantenha a lista de armadilhas em ordem de quanto custa descobrir tarde.

Se o usuário corrigir você durante o projeto, isso também é aprendizado —
principalmente quando a correção vem depois da peça impressa ou do aviso do
slicer. Exemplo registrado: o slicer acusou *floating cantilever* duas vezes
num berço inclinado porque a validação não simulava as camadas; a família I
nasceu disso.